;(function ($) {
    "use strict";
    $(document).on('click','.mobile-bar',function () {
        $(this).closest('.main-menu-wapper').toggleClass('open');
        return false;
    })
})(jQuery, window, document);