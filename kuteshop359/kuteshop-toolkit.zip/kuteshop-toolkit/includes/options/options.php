<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
require_once dirname( __FILE__ ) . '/classes/setup.class.php';