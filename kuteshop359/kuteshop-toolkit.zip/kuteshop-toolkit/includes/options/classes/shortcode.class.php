<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Shortcodes Class
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !class_exists( 'OVIC_Shortcode' ) ) {
	class OVIC_Shortcode extends OVIC_Abstract
	{
		// constans
		public         $options    = array();
		public         $shortcodes = array();
		private static $instance   = null;

		// run shortcode construct
		public function __construct( $settings = array(), $options = array() )
		{
			$this->settings = apply_filters( 'ovic_settings_shortcode', $settings );
			$this->options  = apply_filters( 'ovic_options_shortcode', $options );

			$this->unique_id    = $this->settings['id'];
			$this->button_title = $this->settings['button_title'];
			$this->select_title = $this->settings['select_title'];
			$this->insert_title = $this->settings['insert_title'];

			add_action( 'media_buttons', array( &$this, 'add_shortcode_buttons' ), 99 );
			add_action( 'admin_footer', array( &$this, 'add_shortcode_modal' ) );
			add_action( 'customize_controls_print_footer_scripts', array( &$this, 'add_shortcode_modal' ) );
			add_action( 'wp_ajax_ovic-get-shortcode-' . $this->unique_id, array( &$this, 'get_shortcode' ) );

			// wp enqueue for typography and output css
			parent::__construct();
		}

		// instance
		public static function instance( $settings = array(), $options = array() )
		{
			return new self( $settings, $options );
		}

		public function add_shortcode_buttons( $editor_id )
		{
			echo '<a href="#" class="button button-primary ovic-shortcode-button" data-editor-id="' . $editor_id . '" data-modal-button-id="' . $this->unique_id . '">' . $this->button_title . '</a>';
		}

		public function add_shortcode_modal()
		{
			?>
            <div id="ovic-modal-<?php echo $this->unique_id; ?>" class="ovic-modal ovic-shortcode"
                 data-modal-id="<?php echo $this->unique_id; ?>">
                <div class="ovic-modal-table">
                    <div class="ovic-modal-table-cell">
                        <div class="ovic-modal-overlay"></div>
                        <div class="ovic-modal-inner">
                            <div class="ovic-modal-title">
								<?php echo $this->button_title; ?>
                                <div class="ovic-modal-close"></div>
                            </div>
                            <div class="ovic-modal-header">
                                <select>
                                    <option value=""><?php echo $this->select_title; ?></option>
									<?php
									foreach ( $this->options as $option ) {
										echo ( !empty( $option['title'] ) ) ? '<optgroup label="' . $option['title'] . '">' : '';
										foreach ( $option['shortcodes'] as $shortcode ) {
											$view = ( isset( $shortcode['view'] ) ) ? $shortcode['view'] : 'normal';
											echo '<option value="' . $shortcode['name'] . '" data-view="' . $view . '">' . $shortcode['title'] . '</option>';
										}
										echo ( !empty( $option['title'] ) ) ? '</optgroup>' : '';
									}
									?>
                                </select>
                            </div>
                            <div class="ovic-modal-content"></div>
                            <div class="ovic-modal-insert-wrapper hidden">
                                <a href="#" class="button button-primary ovic-modal-insert">
									<?php echo $this->insert_title; ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}

		public function get_shortcode()
		{
			$unallows = array( 'wysiwyg', 'group', 'fieldset' );

			$request = ovic_get_var( 'shortcode' );

			if ( empty( $request ) ) {
				die();
			}

			$shortcode = array_pop( ovic_array_search( $this->options, 'name', $request ) );

			if ( !empty( $shortcode ) ) {
				foreach ( $shortcode['fields'] as $field ) {
					if ( in_array( $field['type'], $unallows ) ) {
						$field['_notice'] = true;
					}

					if ( !empty( $field['id'] ) ) {
						$field['attributes'] = ( !empty( $field['attributes'] ) ) ? wp_parse_args( array( 'data-atts' => $field['id'] ), $field['attributes'] ) : array( 'data-atts' => $field['id'] );
					}

					$field_default = ( !empty( $field['default'] ) ) ? $field['default'] : '';

					if ( in_array( $field['type'], array( 'image_select', 'checkbox' ) ) && !empty( $field['options'] ) ) {
						$field['attributes']['data-check'] = true;
					}

					echo OVIC::field( $field, $field_default, 'shortcode', 'shortcode' );
				}
			}

			if ( !empty( $shortcode['clone_fields'] ) ) {
				$clone_id = !empty( $shortcode['clone_id'] ) ? $shortcode['clone_id'] : $shortcode['name'];

				echo '<div class="ovic-shortcode-clone" data-clone-id="' . $clone_id . '">';
				echo '<a href="#" class="ovic-remove-clone"><i class="fa fa-trash"></i></a>';

				foreach ( $shortcode['clone_fields'] as $field ) {
					if ( in_array( $field['type'], $unallows ) ) {
						$field['_notice'] = true;
					}

					$field['sub']        = true;
					$field['attributes'] = ( !empty( $field['attributes'] ) ) ? wp_parse_args( array( 'data-clone-atts' => $field['id'] ), $field['attributes'] ) : array( 'data-clone-atts' => $field['id'] );
					$field_default       = ( !empty( $field['default'] ) ) ? $field['default'] : '';

					if ( in_array( $field['type'], array( 'image_select', 'checkbox' ) ) && !empty( $field['options'] ) ) {
						$field['attributes']['data-check'] = true;
					}

					echo OVIC::field( $field, $field_default, 'shortcode', 'shortcode' );
				}

				echo '</div>';

				echo '<div class="ovic-clone-button-wrapper"><a class="button ovic-clone-button" href="#"><i class="fa fa-plus-circle"></i> ' . $shortcode['clone_title'] . '</a></div>';
			}

			die();
		}
	}
}
