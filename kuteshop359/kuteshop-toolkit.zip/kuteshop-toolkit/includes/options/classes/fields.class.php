<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Options Class
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !class_exists( 'OVIC_Fields' ) ) {
	abstract class OVIC_Fields extends OVIC_Abstract
	{
		public function __construct( $field = array(), $value = '', $unique = '', $where = '', $parent = '' )
		{
			$this->field      = $field;
			$this->value      = $value;
			$this->org_value  = $value;
			$this->unique     = $unique;
			$this->where      = $where;
			$this->parent     = $parent;
			$this->multilang  = $this->field_multilang();
			$this->lang_value = $this->field_value( $value );
		}

		public function field_value( $value = '' )
		{
			$value = ( !empty( $value ) ) ? $value : $this->value;
			if ( is_array( $this->multilang ) && is_array( $value ) ) {
				$current = $this->multilang['current'];
				if ( isset( $value[$current] ) ) {
					$value = $value[$current];
				} else if ( $this->multilang['current'] == $this->multilang['default'] ) {
					$value = $this->value;
				} else {
					$value = '';
				}
			} else if ( !is_array( $this->multilang ) && is_array( $this->value ) && isset( $this->value['multilang'] ) ) {
				$value = array_values( (array)$this->value );
				$value = $value[0];
			} else if ( is_array( $this->multilang ) && !is_array( $value ) && ( $this->multilang['current'] != $this->multilang['default'] ) ) {
				$value = '';
			}

			return $value;
		}

		public function field_name( $extra_name = '', $multilang = false )
		{
			$field_id        = ( isset( $this->field['id'] ) ) ? $this->field['id'] : '';
			$extra_multilang = ( !$multilang && is_array( $this->multilang ) ) ? '[' . $this->multilang['current'] . ']' : '';
			$field_unique    = ( !empty( $this->unique ) ) ? $this->unique . '[' . $field_id . ']' : $field_id;

			return ( isset( $this->field['name'] ) ) ? $this->field['name'] . $extra_name : $field_unique . $extra_multilang . $extra_name;
		}

		public function field_type()
		{
			$type = ( isset( $this->field['attributes']['type'] ) ) ? $this->field['attributes']['type'] : $this->field['type'];

			return $type;
		}

		public function field_class( $el_class = '' )
		{
			$field_class = ( isset( $this->field['class'] ) ) ? ' ' . $this->field['class'] : '';

			return ( $field_class || $el_class ) ? ' class="' . $el_class . $field_class . '"' : '';
		}

		public function field_attributes( $el_attributes = array() )
		{
			$attributes = ( isset( $this->field['attributes'] ) ) ? $this->field['attributes'] : array();
			$field_id   = ( isset( $this->field['id'] ) ) ? $this->field['id'] : '';
			if ( $el_attributes !== false ) {
				$sub_elemenet  = ( isset( $this->field['sub'] ) ) ? 'sub-' : '';
				$el_attributes = ( is_string( $el_attributes ) || is_numeric( $el_attributes ) ) ? array( 'data-' . $sub_elemenet . 'depend-id' => $field_id . '_' . $el_attributes ) : $el_attributes;
				$el_attributes = ( empty( $el_attributes ) && isset( $field_id ) ) ? array( 'data-' . $sub_elemenet . 'depend-id' => $field_id ) : $el_attributes;
			}
			$attributes = wp_parse_args( $attributes, $el_attributes );
			$atts       = '';
			if ( !empty( $attributes ) ) {
				foreach ( $attributes as $key => $value ) {
					if ( $value === 'only-key' ) {
						$atts .= ' ' . $key;
					} else {
						$atts .= ' ' . $key . '="' . $value . '"';
					}
				}
			}

			return $atts;
		}

		public function field_before()
		{
			return ( !empty( $this->field['before'] ) ) ? $this->field['before'] : '';
		}

		public function field_after()
		{
			$outputput = '';
			//$outputput = ( !empty( $this->field['desc'] ) ) ? '<p class="ovic-text-desc">' . $this->field['desc'] . '</p>' : '';
			$outputput .= ( !empty( $this->field['after'] ) ) ? $this->field['after'] : '';
			$outputput .= ( !empty( $this->field['help'] ) ) ? '<span class="ovic-help"><span class="ovic-help-text">' . $this->field['help'] . '</span><span class="fa fa-question-circle"></span></span>' : '';
			$outputput .= ( !empty( $this->field['_error'] ) ) ? '<p class="ovic-text-error">' . $this->field['_error'] . '</p>' : '';
			$outputput .= $this->field_after_multilang();
			$outputput .= $this->field_debug();

			return $outputput;
		}

		public function field_debug()
		{
			$output = '';
			if ( !empty( $this->where ) && ( !empty( $this->field['debug'] ) || ( defined( 'OVIC_DEBUG' ) && OVIC_DEBUG ) ) ) {
				$value  = $this->field_value();
				$output .= "<pre>";
				$output .= "<strong>" . esc_html__( 'CONFIG', 'ovic-addon-toolkit' ) . ":</strong>";
				$output .= "\n";
				ob_start();
				var_export( $this->field );
				$output .= htmlspecialchars( ob_get_clean() );
				$output .= "\n";
				if ( !empty( $this->field['id'] ) ) {
					$output .= "\n";
					$output .= "<strong>" . esc_html__( 'ID', 'ovic-addon-toolkit' ) . ":</strong>";
					$output .= "\n";
					$output .= $this->field['id'];
					$output .= "\n";
					$output .= "\n";
					$output .= "<strong>" . esc_html__( 'USAGE', 'ovic-addon-toolkit' ) . ":</strong>";
					$output .= "\n";
					if ( $this->where === 'options' || $this->where === 'customize' ) {
						$output .= "\$my_options = get_option( '" . $this->unique . "' );\necho \$my_options['" . $this->field['id'] . "'];";
					} else if ( $this->where === 'metabox' ) {
						$output .= "\$my_options = get_post_meta( THE_POST_ID, '" . $this->unique . "', true );\necho \$my_options['" . $this->field['id'] . "'];";
					} else if ( $this->where === 'taxonomy' ) {
						$output .= "\$my_options = get_term_meta( THE_TERM_ID, '" . $this->unique . "', true );\necho \$my_options['" . $this->field['id'] . "'];";
					}
					if ( isset( $value ) ) {
						$output .= "\n\n";
						$output .= "<strong>" . esc_html__( 'VALUE', 'ovic-addon-toolkit' ) . ":</strong>";
						$output .= "\n";
						ob_start();
						var_export( $value );
						$output .= htmlspecialchars( ob_get_clean() );
					}
				}
				$output .= "</pre>";
			}
			if ( !empty( $this->where ) && !empty( $this->field['id'] ) && ( !empty( $this->field['debug_light'] ) || ( defined( 'OVIC_DEBUG_LIGHT' ) && OVIC_DEBUG_LIGHT ) ) ) {
				$output .= "<pre>";
				$output .= "\n";
				$output .= "<strong>" . esc_html__( 'ID', 'ovic-addon-toolkit' ) . ":</strong>";
				$output .= "\n";
				$output .= $this->field['id'];
				$output .= "\n";
				$output .= "\n";
				$output .= "<strong>" . esc_html__( 'USAGE', 'ovic-addon-toolkit' ) . ":</strong>";
				$output .= "\n";
				if ( $this->where === 'options' || $this->where === 'customize' ) {
					$output .= "\$my_options = get_option( '" . $this->unique . "' );\necho \$my_options['" . $this->field['id'] . "'];";
				} else if ( $this->where === 'metabox' ) {
					$output .= "\$my_options = get_post_meta( THE_POST_ID, '" . $this->unique . "', true );\necho \$my_options['" . $this->field['id'] . "'];";
				} else if ( $this->where === 'taxonomy' ) {
					$output .= "\$my_options = get_term_meta( THE_TERM_ID, '" . $this->unique . "', true );\necho \$my_options['" . $this->field['id'] . "'];";
				}
				$output .= "\n";
				$output .= "</pre>";
			}

			return $output;
		}

		public function field_after_multilang()
		{
			$output = '';
			if ( is_array( $this->multilang ) ) {
				$output .= '<fieldset class="hidden">';
				foreach ( $this->multilang['languages'] as $key => $val ) {
					// ignore current language for hidden element
					if ( $key != $this->multilang['current'] ) {
						// set default value
						if ( isset( $this->org_value[$key] ) ) {
							$value = $this->org_value[$key];
						} else if ( !isset( $this->org_value[$key] ) && ( $key == $this->multilang['default'] ) ) {
							$value = $this->org_value;
						} else {
							$value = '';
						}
						$cache_field = $this->field;
						unset( $cache_field['multilang'] );
						$cache_field['name'] = $this->field_name( '[' . $key . ']', true );
						$output              .= OVIC::field( $cache_field, $value, $this->unique );
					}
				}
				$output .= '<input type="hidden" name="' . $this->field_name( '[multilang]', true ) . '" value="true" />';
				$output .= '</fieldset>';
				$output .= '<p class="ovic-text-desc">' . sprintf( '%s ( <strong>%s</strong> )', esc_html__( 'You are editing language:', 'ovic-addon-toolkit' ), $this->multilang['current'] ) . '</p>';
			}

			return $output;
		}

		public function field_data( $type = '' )
		{
			$options    = array();
			$query_args = ( isset( $this->field['query_args'] ) ) ? $this->field['query_args'] : array();
			switch ( $type ) {
				case 'pages':
				case 'page':
					$pages = get_pages( $query_args );
					if ( !is_wp_error( $pages ) && !empty( $pages ) ) {
						foreach ( $pages as $page ) {
							$options[$page->ID] = $page->post_title;
						}
					}
					break;
				case 'posts':
				case 'post':
					$posts = get_posts( $query_args );
					if ( !is_wp_error( $posts ) && !empty( $posts ) ) {
						foreach ( $posts as $post ) {
							$options[$post->ID] = $post->post_title;
						}
					}
					break;
				case 'categories':
				case 'category':
					$categories = get_categories( $query_args );
					if ( !is_wp_error( $categories ) && !empty( $categories ) && !isset( $categories['errors'] ) ) {
						foreach ( $categories as $category ) {
							$options[$category->term_id] = $category->name;
						}
					}
					break;
				case 'tags':
				case 'tag':
					$taxonomies = ( isset( $query_args['taxonomies'] ) ) ? $query_args['taxonomies'] : 'post_tag';
					$tags       = get_terms( $taxonomies, $query_args );
					if ( !is_wp_error( $tags ) && !empty( $tags ) ) {
						foreach ( $tags as $tag ) {
							$options[$tag->term_id] = $tag->name;
						}
					}
					break;
				case 'menus':
				case 'menu':
					$menus = wp_get_nav_menus( $query_args );
					if ( !is_wp_error( $menus ) && !empty( $menus ) ) {
						foreach ( $menus as $menu ) {
							$options[$menu->term_id] = $menu->name;
						}
					}
					break;
				case 'post_types':
				case 'post_type':
					$post_types = get_post_types( array(
							'show_in_nav_menus' => true,
						)
					);
					if ( !is_wp_error( $post_types ) && !empty( $post_types ) ) {
						foreach ( $post_types as $post_type ) {
							$options[$post_type] = ucfirst( $post_type );
						}
					}
					break;
				case 'sidebar':
				case 'sidebars':
					global $wp_registered_sidebars;
					if ( !empty( $wp_registered_sidebars ) ) {
						foreach ( $wp_registered_sidebars as $sidebar ) {
							$options[$sidebar['id']] = $sidebar['name'];
						}
					}
					break;
				case 'role':
				case 'roles':
					global $wp_roles;
					if ( is_object( $wp_roles ) ) {
						$roles = $wp_roles->get_names();
						if ( !empty( $wp_roles ) ) {
							foreach ( $roles as $key => $value ) {
								$options[$key] = $value;
							}
						}
					}
					break;
				default:
					if ( is_callable( $query_args['function'] ) ) {
						$options = call_user_func( $query_args['function'], $query_args['args'] );
					}
					break;
			}

			return $options;
		}

		public function checked( $helper = '', $current = '', $type = 'checked', $echo = false )
		{
			if ( is_array( $helper ) && in_array( $current, $helper ) ) {
				$result = ' ' . $type . '="' . $type . '"';
			} else if ( !is_array( $helper ) && (string)$helper === (string)$current ) {
				$result = ' ' . $type . '="' . $type . '"';
			} else {
				$result = '';
			}
			if ( $echo ) {
				echo $result;
			}

			return $result;
		}

		public function field_multilang()
		{
			return ( isset( $this->field['multilang'] ) ) ? ovic_language_defaults() : false;
		}
	}
}
