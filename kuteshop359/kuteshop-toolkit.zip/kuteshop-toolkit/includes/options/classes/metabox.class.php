<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Metabox Class
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !class_exists( 'OVIC_Metabox' ) ) {
	class OVIC_Metabox extends OVIC_Abstract
	{
		// constans
		public $options  = array();
		public $errors   = array();
		public $abstract = 'metabox';
		// default args
		public $args = array(
			// typography options
			'enqueue_webfont' => true,
			'async_webfont'   => false,
			// others
			'output_css'      => true,
		);

		// run metabox construct
		public function __construct( $options )
		{
			// Get options metabox
			$this->args    = apply_filters( "ovic_options_metabox_settings", $this->args, $this );
			$this->options = apply_filters( 'ovic_options_metabox', $options );

			if ( in_array( $GLOBALS['pagenow'], array( 'edit.php', 'post.php', 'post-new.php' ) ) ) {
				// Actions metabox
				add_action( 'add_meta_boxes', array( &$this, 'add_meta_box' ) );
				add_action( 'save_post', array( &$this, 'save_meta_box' ), 10, 2 );
			}

			// wp enqueue for typography and output css
			parent::__construct();
		}

		// instance
		public static function instance( $options = array() )
		{
			return new self( $options );
		}

		// add metabox
		public function add_meta_box( $post_type )
		{
			foreach ( $this->options as $value ) {
				//$value['__back_compat_meta_box'] = true;
				add_meta_box(
					$value['id'],
					$value['title'],
					array( &$this, 'add_meta_box_content' ),
					$value['post_type'],
					$value['context'],
					$value['priority'],
					$value
				);
			}
		}

		// add metabox content
		public function add_meta_box_content( $post, $callback )
		{
			global $post, $typenow;
			wp_nonce_field( 'ovic-metabox', 'ovic-metabox-nonce' );
			$args       = $callback['args'];
			$unique     = $args['id'];
			$sections   = ( !empty( $args['sections'] ) ) ? $args['sections'] : $args['fields'];
			$meta_value = get_post_meta( $post->ID, $unique, true );
			$has_nav    = ( count( $sections ) >= 2 && $args['context'] != 'side' ) ? true : false;
			$show_all   = ( !$has_nav ) ? ' ovic-show-all' : '';
			$timenow    = round( microtime( true ) );
			$errors     = ( isset( $meta_value['_transient']['errors'] ) ) ? $meta_value['_transient']['errors'] : array();
			$section    = ( isset( $meta_value['_transient']['section'] ) ) ? $meta_value['_transient']['section'] : false;
			$expires    = ( isset( $meta_value['_transient']['expires'] ) ) ? $meta_value['_transient']['expires'] : 0;
			$timein     = ovic_timeout( $timenow, $expires, 20 );
			$section_id = ( $timein && $section ) ? $section : '';
			$section_id = ovic_get_var( 'ovic-section', $section_id );

			// add erros
			$this->errors = ( $timein ) ? $errors : array();

			do_action( 'ovic_html_metabox_before' );

			echo '<div class="ovic ovic-theme-dark ovic-metabox">';

			echo '<input type="hidden" name="' . $unique . '[_transient][section]" class="ovic-section-id" value="' . $section_id . '">';

			echo '<div class="ovic-wrapper' . $show_all . '">';

			if ( $has_nav ) {
				echo '<div class="ovic-nav ovic-nav-metabox" data-unique="' . $unique . '">';
				echo '<ul>';
				$num = 0;
				foreach ( $sections as $tab ) {
					if ( !empty( $tab['typenow'] ) && $tab['typenow'] !== $typenow ) {
						continue;
					}
					$tab_error = $this->error_check( $tab );
					$tab_icon  = ( !empty( $tab['icon'] ) ) ? '<i class="ovic-icon ' . $tab['icon'] . '"></i>' : '';
					if ( isset( $tab['fields'] ) ) {
						echo '<li><a href="#" data-section="' . $unique . '_' . $tab['name'] . '">' . $tab_icon . $tab['title'] . $tab_error . '</a></li>';
					} else {
						echo '<li><div class="ovic-seperator">' . $tab_icon . $tab['title'] . $tab_error . '</div></li>';
					}
					$num++;
				}
				echo '</ul>';
				echo '</div>';
			}

			echo '<div class="ovic-content">';

			echo '<div class="ovic-sections">';

			$num = 0;

			foreach ( $sections as $fields ) {
				if ( !empty( $fields['typenow'] ) && $fields['typenow'] !== $typenow ) {
					continue;
				}
				if ( isset( $fields['fields'] ) ) {
					$active_content = ( !$has_nav ) ? 'ovic-onload' : '';

					echo '<div id="ovic-section-' . $unique . '_' . $fields['name'] . '" class="ovic-section ' . $active_content . '">';

					echo ( isset( $fields['title'] ) ) ? '<div class="ovic-section-title"><h3>' . $fields['title'] . '</h3></div>' : '';

					foreach ( $fields['fields'] as $field_key => $field ) {
						$is_field_error = $this->error_check( $field );
						if ( !empty( $is_field_error ) ) {
							$field['_error'] = $is_field_error;
						}
						$default    = ( isset( $field['default'] ) ) ? $field['default'] : '';
						$elem_id    = ( isset( $field['id'] ) ) ? $field['id'] : '';
						$elem_value = ( is_array( $meta_value ) && isset( $meta_value[$elem_id] ) ) ? $meta_value[$elem_id] : $default;
						echo OVIC::field( $field, $elem_value, $unique, 'metabox' );
					}

					echo '</div>';
				}
				$num++;
			}

			echo '</div>';

			echo '<div class="clear"></div>';

			if ( !empty( $args['show_restore'] ) ) {
				echo '<div class=" ovic-metabox-restore">';
				echo '<label>';
				echo '<input type="checkbox" name="' . $unique . '[_restore]" />';
				echo '<span class="button ovic-button-restore">' . esc_html__( 'Restore', 'ovic-addon-toolkit' ) . '</span>';
				echo '<span class="button ovic-button-cancel">' . sprintf( '<small>( %s )</small> %s', esc_html__( 'update post for restore ', 'ovic-addon-toolkit' ), esc_html__( 'Cancel', 'ovic-addon-toolkit' ) ) . '</span>';
				echo '</label>';
				echo '</div>';
			}

			echo '</div>';
			echo ( $has_nav ) ? '<div class="ovic-nav-background"></div>' : '';
			echo '<div class="clear"></div>';
			echo '</div>';
			echo '</div>';

			do_action( 'ovic_html_metabox_after' );
		}

		// save metabox
		public function save_meta_box( $post_id, $post )
		{
			if ( wp_verify_nonce( ovic_get_var( 'ovic-metabox-nonce' ), 'ovic-metabox' ) ) {
				$errors    = array();
				$post_type = ovic_get_var( 'post_type' );
				foreach ( $this->options as $request_value ) {
					if ( in_array( $post_type, (array)$request_value['post_type'] ) ) {
						$request_key = $request_value['id'];
						$request     = ovic_get_var( $request_key, array() );
						// ignore _nonce
						if ( isset( $request['_nonce'] ) ) {
							unset( $request['_nonce'] );
						}
						// sanitize and validate
						foreach ( $request_value['sections'] as $key => $section ) {
							if ( !empty( $section['fields'] ) ) {
								foreach ( $section['fields'] as $field ) {
									if ( !empty( $field['id'] ) ) {
										// sanitize
										if ( !empty( $field['sanitize'] ) ) {
											$sanitize = $field['sanitize'];
											if ( function_exists( $sanitize ) ) {
												$value_sanitize        = ovic_get_vars( $request_key, $field['id'] );
												$request[$field['id']] = call_user_func( $sanitize, $value_sanitize );
											}
										}
										// validate
										if ( !empty( $field['validate'] ) ) {
											$validate = $field['validate'];
											if ( function_exists( $validate ) ) {
												$value_validate = ovic_get_vars( $request_key, $field['id'] );
												$has_validated  = call_user_func( $validate, array( 'value' => $value_validate, 'field' => $field ) );
												if ( !empty( $has_validated ) ) {
													$meta_value            = get_post_meta( $post_id, $request_key, true );
													$errors[$field['id']]  = $has_validated;
													$default_value         = isset( $field['default'] ) ? $field['default'] : '';
													$request[$field['id']] = ( isset( $meta_value[$field['id']] ) ) ? $meta_value[$field['id']] : $default_value;
												}
											}
										}
										// auto sanitize
										if ( !isset( $request[$field['id']] ) || is_null( $request[$field['id']] ) ) {
											$request[$field['id']] = '';
										}
									}
								}
							}
						}
						$request['_transient']['expires'] = round( microtime( true ) );
						if ( !empty( $errors ) ) {
							$request['_transient']['errors'] = $errors;
						}
						$request = apply_filters( 'ovic_save_metabox', $request, $request_key, $post );
						if ( empty( $request ) || !empty( $request['_restore'] ) ) {
							delete_post_meta( $post_id, $request_key );
						} else {
							update_post_meta( $post_id, $request_key, $request );
						}
					}
				}
			}
		}
	}
}
