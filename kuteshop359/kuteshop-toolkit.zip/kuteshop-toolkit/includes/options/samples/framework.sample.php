<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.

//
// Framework Settings
//
$settings = array(
	'option_name'      => '_ovic_sample_options',
	'menu_title'       => 'Sample Options',
	'menu_type'        => 'submenu', // menu, submenu, options, theme, etc.
	'menu_slug'        => 'ovic_sample_options',
	'menu_parent'      => 'ovic_addon-dashboard',
	'menu_position'    => 5,
	'show_search'      => true,
	'show_reset'       => true,
	'show_footer'      => false,
	'show_all_options' => true,
	'ajax_save'        => true,
	'sticky_header'    => false,
	'save_defaults'    => true,
	'framework_title'  => 'Sample Options <small>by <a href="https://kutethemes.com/" target="_blank">Kutethemes</a></small>',
);

//
// Framework Options
//
$options = array();

$options[] = array(
	'name'        => 'overwiew',
	'title'       => 'Overview',
	'icon'        => 'fa fa-star',
	'description' => 'Description Overview',
	'fields'      => array(

		array(
			'id'        => 'text_1',
			'type'      => 'text',
			'title'     => 'Text',
			'multilang' => true,
		),

		array(
			'id'        => 'textarea_1',
			'type'      => 'textarea',
			'title'     => 'Textarea',
			'multilang' => true,
			'help'      => 'This option field is useful. &quot;You&quot; will love it! This option field is useful. You will love it!',
		),

		array(
			'id'        => 'upload_1',
			'type'      => 'upload',
			'title'     => 'Upload',
			'multilang' => true,
			'help'      => 'Upload a site logo for your branding.',
		),

		array(
			'id'        => 'switcher_1',
			'type'      => 'switcher',
			'title'     => 'Switcher',
			'multilang' => true,
			'label'     => 'You want to update for this framework ?',
		),

		array(
			'id'        => 'color_picker_1',
			'type'      => 'color',
			'title'     => 'Color Picker',
			'default'   => '#3498db',
			'multilang' => true,
		),

		array(
			'id'        => 'checkbox_1',
			'type'      => 'checkbox',
			'title'     => 'Checkbox',
			'multilang' => true,
			'label'     => 'Did you like this framework ?',
		),

		array(
			'id'      => 'radio_1',
			'type'    => 'radio',
			'title'   => 'Radio',
			'options' => array(
				'yes' => 'Yes, Please.',
				'no'  => 'No, Thank you.',
			),
			'help'    => 'Are you sure for this choice?',
		),

		array(
			'id'             => 'select_1',
			'type'           => 'select',
			'title'          => 'Select',
			'options'        => array(
				'bmw'        => 'BMW',
				'mercedes'   => 'Mercedes',
				'volkswagen' => 'Volkswagen',
				'other'      => 'Other',
			),
			'multilang'      => true,
			'default_option' => 'Select your favorite car',
		),

		array(
			'id'      => 'number_1',
			'type'    => 'number',
			'title'   => 'Number',
			'default' => '10',
			'after'   => ' <i class="ovic-text-muted">$ (dollars)</i>',
		),

		array(
			'id'      => 'image_select_1',
			'type'    => 'image_select',
			'title'   => 'Image Select',
			'options' => array(
				'value-1' => 'https://codestarframework.com/assets/images/placeholder/100x80-2ecc71.gif',
				'value-2' => 'https://codestarframework.com/assets/images/placeholder/100x80-e74c3c.gif',
				'value-3' => 'https://codestarframework.com/assets/images/placeholder/100x80-ffbc00.gif',
				'value-4' => 'https://codestarframework.com/assets/images/placeholder/100x80-3498db.gif',
				'value-5' => 'https://codestarframework.com/assets/images/placeholder/100x80-555555.gif',
			),
		),

		array(
			'type'    => 'notice',
			'class'   => 'info',
			'content' => 'This is info notice field for your highlight sentence.',
		),

		array(
			'id'    => 'background_1',
			'type'  => 'background',
			'title' => 'Background',
		),

		array(
			'type'    => 'notice',
			'class'   => 'warning',
			'content' => 'This is info warning field for your highlight sentence.',
		),

		array(
			'id'    => 'icon_1',
			'type'  => 'icon',
			'title' => 'Icon',
			'desc'  => 'Some description here for this option field.',
		),

		array(
			'id'    => 'text_2',
			'type'  => 'text',
			'title' => 'Text',
			'desc'  => 'Some description here for this option field.',
		),

		array(
			'id'        => 'textarea_2',
			'type'      => 'textarea',
			'title'     => 'Textarea',
			'info'      => 'Some information here for this option field.',
			'shortcode' => array(
				'id'    => 'ovic_shortcode',
				'title' => 'Add Shortcode',
			),
		),

	),
);

// ------------------------------
// a option section with tabs   -
// ------------------------------
$options[] = array(
	'name'     => 'options',
	'title'    => 'Options',
	'icon'     => 'fa fa-plus-circle',
	'sections' => array(

		//
		// Text
		//
		array(
			'name'   => 'text_options',
			'title'  => 'Text',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'unique_text_1',
					'type'  => 'text',
					'title' => 'Text',
				),

				array(
					'id'    => 'unique_text_2',
					'type'  => 'text',
					'title' => 'Text with Description',
					'desc'  => 'Lets write some description.',
				),

				array(
					'id'    => 'unique_text_3',
					'type'  => 'text',
					'title' => 'Text with Help',
					'help'  => 'I am a Tooltip helper. This field important for something.',
				),

				array(
					'id'      => 'unique_text_4',
					'type'    => 'text',
					'title'   => 'Text with Default',
					'default' => 'some default value bla bla bla',
				),

				array(
					'id'         => 'unique_text_5',
					'type'       => 'text',
					'title'      => 'Text with Placeholder',
					'attributes' => array(
						'placeholder' => 'do stuff...',
					),
				),

				array(
					'id'    => 'unique_text_6',
					'type'  => 'text',
					'title' => 'Text with After Text',
					'after' => ' Something for after text.',
				),

				array(
					'id'     => 'unique_text_7',
					'type'   => 'text',
					'title'  => 'Text with Before Text',
					'before' => 'Something for before text. ',
				),

				array(
					'id'    => 'unique_text_8',
					'type'  => 'text',
					'title' => 'Text with After Text Alternative',
					'after' => '<p class="ovic-text-success">Information: There is some description for option.</p> ',
				),

				array(
					'id'         => 'unique_text_9',
					'type'       => 'text',
					'title'      => 'Text Ready-Only',
					'attributes' => array(
						'readonly' => 'only-key',
					),
					'default'    => 'Only read me',
				),

				array(
					'id'         => 'unique_text_10',
					'type'       => 'text',
					'title'      => 'Text Maxlength (5)',
					'attributes' => array(
						'maxlength' => '5',
					),
					'default'    => 'abcde',
				),

				array(
					'id'         => 'unique_text_11',
					'type'       => 'text',
					'title'      => 'Text Using Custom Style',
					'attributes' => array(
						'style' => 'width: 175px; height: 40px; border-color: #93C054;',
					),
				),

				array(
					'id'         => 'unique_text_12',
					'type'       => 'text',
					'title'      => 'Text Using Custom Style',
					'attributes' => array(
						'style' => 'width: 100%;',
					),
				),

				array(
					'id'    => 'unique_text_13',
					'type'  => 'text',
					'after' => '<p>This text not using title.</p>',
				),

			),
		),

		//
		// Textarea
		//
		array(
			'name'   => 'textarea_options',
			'title'  => 'Textarea',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'unique_textarea_1',
					'type'  => 'textarea',
					'title' => 'Textarea',
				),

				array(
					'id'        => 'unique_textarea_1_1',
					'type'      => 'textarea',
					'title'     => 'Textarea with Quick Shortcode',
					'shortcode' => array(
						'id'    => 'ovic_shortcode',
						'title' => 'Add Shortcode',
					),
				),

				array(
					'id'    => 'unique_textarea_2',
					'type'  => 'textarea',
					'title' => 'Textarea with Description',
					'desc'  => 'Lets write some description.',
				),

				array(
					'id'    => 'unique_textarea_3',
					'type'  => 'textarea',
					'title' => 'Textarea with Help',
					'help'  => 'I am a Tooltip helper. This field important for something.',
				),

				array(
					'id'      => 'unique_textarea_4',
					'type'    => 'textarea',
					'title'   => 'Textarea with Default',
					'default' => 'some default value bla bla bla',
				),

				array(
					'id'         => 'unique_textarea_5',
					'type'       => 'textarea',
					'title'      => 'Textarea with Placeholder',
					'attributes' => array(
						'placeholder' => 'do stuff...',
					),
				),

				array(
					'id'    => 'unique_textarea_6',
					'type'  => 'textarea',
					'title' => 'Textarea with After Text',
					'after' => ' Something for after text.',
				),

				array(
					'id'     => 'unique_textarea_7',
					'type'   => 'textarea',
					'title'  => 'Textarea with Before Text',
					'before' => 'Something for before text. ',
				),

				array(
					'id'         => 'unique_textarea_8',
					'type'       => 'textarea',
					'title'      => 'Textarea Custom Settings',
					'attributes' => array(
						'rows' => 10,
					),
				),

				array(
					'id'    => 'unique_textarea_13',
					'type'  => 'textarea',
					'after' => '<p>This textarea not using title.</p>',
				),

			),

		),

		//
		// Checkbox
		//
		array(
			'name'   => 'checkbox_options',
			'title'  => 'Checkbox',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'unique_checkbox_1',
					'type'  => 'checkbox',
					'title' => 'Checkbox',
					'label' => 'Yes, Please.',
				),

				array(
					'id'      => 'unique_checkbox_2',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Default',
					'label'   => 'Would you like something ?',
					'default' => true,
				),

				array(
					'id'    => 'unique_checkbox_3',
					'type'  => 'checkbox',
					'title' => 'Checkbox with Help',
					'label' => 'I am an checkbox',
					'help'  => 'I am a Tooltip helper. This field important for something.',
				),

				array(
					'id'      => 'unique_checkbox_4',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Options',
					'options' => array(
						'blue'   => 'Blue',
						'green'  => 'Green',
						'yellow' => 'Yellow',
					),
				),

				array(
					'id'      => 'unique_checkbox_5',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Options and Default',
					'options' => array(
						'bmw'      => 'BMW',
						'mercedes' => 'Mercedes',
						'jaguar'   => 'Jaguar',
					),
					'default' => 'bmw',
				),

				array(
					'id'      => 'unique_checkbox_6',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Horizontal',
					'class'   => 'horizontal',
					'options' => array(
						'blue'   => 'Blue',
						'green'  => 'Green',
						'yellow' => 'Yellow',
						'red'    => 'Red',
						'black'  => 'Black',
					),
					'default' => array( 'green', 'yellow', 'red' ),
				),

				array(
					'id'      => 'unique_checkbox_7',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Pages',
					'options' => 'pages',
				),

				array(
					'id'      => 'unique_checkbox_8',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Posts',
					'options' => 'posts',
				),

				array(
					'id'      => 'unique_checkbox_9',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Categories',
					'options' => 'categories',
				),

				array(
					'id'         => 'unique_checkbox_10',
					'type'       => 'checkbox',
					'title'      => 'Checkbox with Pages Custom Query Args',
					'options'    => 'pages',
					'query_args' => array(
						'sort_order'  => 'desc',
						'sort_column' => 'post_title',
					),
				),

				array(
					'id'      => 'unique_checkbox_11',
					'type'    => 'checkbox',
					'title'   => 'Checkbox with Options Callback',
					'options' => ovic_get_custom_options(),
				),

			),
		),

		//
		// Radio
		//
		array(
			'name'   => 'radio_options',
			'title'  => 'Radio',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'      => 'unique_radio_1',
					'type'    => 'radio',
					'title'   => 'Radio',
					'options' => array(
						'yes' => 'Yes, Please.',
						'no'  => 'No, Thank you.',
					),
				),

				array(
					'id'      => 'unique_radio_2',
					'type'    => 'radio',
					'title'   => 'Radio with Default',
					'options' => array(
						'yes'     => 'Yes, Please.',
						'no'      => 'No, Thank you.',
						'nothing' => 'I am not sure, yet!',
					),
					'default' => 'nothing',
				),

				array(
					'id'      => 'unique_radio_3',
					'type'    => 'radio',
					'title'   => 'Radio with Horizontal',
					'class'   => 'horizontal',
					'options' => array(
						'yes' => 'Yes, Please.',
						'no'  => 'No, Thank you.',
					),
				),

				array(
					'id'      => 'unique_radio_4',
					'type'    => 'radio',
					'title'   => 'Radio with Pages',
					'options' => 'pages',
				),

				array(
					'id'      => 'unique_radio_5',
					'type'    => 'radio',
					'title'   => 'Radio with Posts',
					'options' => 'posts',
				),

				array(
					'id'      => 'unique_radio_6',
					'type'    => 'radio',
					'title'   => 'Radio with Categories',
					'options' => 'categories',
				),

				array(
					'id'         => 'unique_radio_7',
					'type'       => 'radio',
					'title'      => 'Radio with Pages',
					'options'    => 'pages',
					'query_args' => array(
						'sort_order'  => 'desc',
						'sort_column' => 'post_title',
					),
				),

				array(
					'id'      => 'unique_radio_8',
					'type'    => 'radio',
					'title'   => 'Radio with Custom Callback',
					'options' => ovic_get_custom_options(),
				),

			),
		),

		//
		// Select
		//
		array(
			'name'   => 'select_options',
			'title'  => 'Select',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'          => 'opt-select-1',
					'type'        => 'select',
					'title'       => 'Select',
					'placeholder' => 'Select an option',
					'options'     => array(
						'opt-1' => 'Option 1',
						'opt-2' => 'Option 2',
						'opt-3' => 'Option 3',
					),
				),

				array(
					'id'          => 'opt-select-2',
					'type'        => 'select',
					'title'       => 'Select with default',
					'placeholder' => 'Select an option',
					'options'     => array(
						'opt-1' => 'Option 1',
						'opt-2' => 'Option 2',
						'opt-3' => 'Option 3',
					),
					'default'     => 'opt-2',
				),

				array(
					'id'          => 'opt-select-3',
					'type'        => 'select',
					'title'       => 'Select with group related options',
					'placeholder' => 'Select an option',
					'options'     => array(
						'Group 1' => array(
							'opt-1' => 'Option 1',
							'opt-2' => 'Option 2',
							'opt-3' => 'Option 3',
						),
						'Group 2' => array(
							'opt-4' => 'Option 4',
							'opt-5' => 'Option 5',
							'opt-6' => 'Option 6',
						),
						'Group 3' => array(
							'opt-7' => 'Option 7',
							'opt-8' => 'Option 8',
							'opt-9' => 'Option 9',
						),
					),
				),

				array(
					'id'         => 'opt-select-4',
					'type'       => 'select',
					'title'      => 'Select with multiple choice',
					'multiple'   => true,
					'attributes' => array(
						'style' => 'min-width: 200px;',
					),
					'options'    => array(
						'opt-1' => 'Option 1',
						'opt-2' => 'Option 2',
						'opt-3' => 'Option 3',
						'opt-4' => 'Option 4',
						'opt-5' => 'Option 5',
						'opt-6' => 'Option 6',
					),
					'default'    => array( 'opt-2', 'opt-3' ),
				),

				array(
					'type'    => 'notice',
					'style'   => 'info',
					'content' => 'Select with <strong>chosen</strong> style.',
				),

				array(
					'id'          => 'opt-select-5',
					'type'        => 'select',
					'title'       => 'Select with chosen style',
					'chosen'      => true,
					'placeholder' => 'Select an option',
					'options'     => array(
						'opt-1' => 'Option 1',
						'opt-2' => 'Option 2',
						'opt-3' => 'Option 3',
						'opt-4' => 'Option 4',
						'opt-5' => 'Option 5',
						'opt-6' => 'Option 6',
					),
				),

				array(
					'id'          => 'opt-select-6',
					'type'        => 'select',
					'title'       => 'Select with multiple chosen style',
					'chosen'      => true,
					'multiple'    => true,
					'placeholder' => 'Select an option',
					'options'     => array(
						'opt-1' => 'Option 1',
						'opt-2' => 'Option 2',
						'opt-3' => 'Option 3',
						'opt-4' => 'Option 4',
						'opt-5' => 'Option 5',
						'opt-6' => 'Option 6',
					),
				),

				array(
					'type'    => 'notice',
					'style'   => 'info',
					'content' => 'Select with <strong>predefined wp query</strong> options.',
				),

				array(
					'id'          => 'opt-select-7',
					'type'        => 'select',
					'title'       => 'Select with pages',
					'placeholder' => 'Select a page',
					'options'     => 'pages',
				),

				array(
					'id'          => 'opt-select-8',
					'type'        => 'select',
					'title'       => 'Select with posts',
					'placeholder' => 'Select a post',
					'options'     => 'posts',
				),

				array(
					'id'          => 'opt-select-9',
					'type'        => 'select',
					'title'       => 'Select with categories',
					'placeholder' => 'Select a category',
					'options'     => 'categories',
				),

				array(
					'id'          => 'opt-select-10',
					'type'        => 'select',
					'title'       => 'Select with menus',
					'placeholder' => 'Select a menu',
					'options'     => 'menus',
				),

				array(
					'id'          => 'opt-select-11',
					'type'        => 'select',
					'title'       => 'Select with sidebars',
					'placeholder' => 'Select a sidebar',
					'options'     => 'sidebars',
				),

				array(
					'id'          => 'opt-select-12',
					'type'        => 'select',
					'title'       => 'Select with wp roles',
					'placeholder' => 'Select a role',
					'options'     => 'roles',
				),

				array(
					'id'          => 'opt-select-13',
					'type'        => 'select',
					'title'       => 'Select with CPT (custom post type) posts',
					'placeholder' => 'Select a post',
					'options'     => 'posts',
					'query_args'  => array(
						'post_type' => 'your_post_type_name',
					),
				),

				array(
					'id'          => 'opt-select-14',
					'type'        => 'select',
					'title'       => 'Select with CPT (custom post type) categories',
					'placeholder' => 'Select a category',
					'options'     => 'categories',
					'query_args'  => array(
						'type'     => 'your_post_type_name',
						'taxonomy' => 'your_taxonomy_name',
					),
				),

			),
		),

		//
		// Switcher
		//
		array(
			'name'   => 'switcher_options',
			'title'  => 'Switcher',
			'icon'   => 'fa fa-toggle-on',
			'fields' => array(

				array(
					'id'    => 'unique_switcher_1',
					'type'  => 'switcher',
					'title' => 'Switcher',
				),

				array(
					'id'    => 'unique_switcher_2',
					'type'  => 'switcher',
					'title' => 'Switcher with Label',
					'label' => 'Yes, Please do it.',
				),

				array(
					'id'    => 'unique_switcher_3',
					'type'  => 'switcher',
					'title' => 'Switcher with Help',
					'help'  => 'I am a Tooltip helper. This field important for something.',
				),

				array(
					'id'      => 'unique_switcher_4',
					'type'    => 'switcher',
					'title'   => 'Switcher with Default',
					'default' => true,
				),

			),
		),

		//
		// Spinner Options
		//
		array(
			'name'   => 'spinner_options',
			'title'  => 'spinner',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'       => 'opt-spinner-1',
					'type'     => 'spinner',
					'title'    => 'Spinner',
					'subtitle' => 'max:100 | min:0 | step:1',
					'max'      => 100,
					'min'      => 0,
					'step'     => 1,
					'default'  => 25,
				),

				array(
					'id'       => 'opt-spinner-2',
					'type'     => 'spinner',
					'title'    => 'Spinner',
					'subtitle' => 'max:200 | min:100 | step:10',
					'max'      => 200,
					'min'      => 100,
					'step'     => 10,
					'default'  => 100,
				),

				array(
					'id'       => 'opt-spinner-3',
					'type'     => 'spinner',
					'title'    => 'Spinner',
					'subtitle' => 'max:1 | min:0 | step:0.1 | unit:px',
					'max'      => 1,
					'min'      => 0,
					'step'     => 0.1,
					'unit'     => 'px',
					'default'  => 0.5,
				),

			),
		),

		//
		// Number Options
		//
		array(
			'name'   => 'number_options',
			'title'  => 'Number',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'unique_number_1',
					'type'  => 'number',
					'title' => 'Number',
				),

				array(
					'id'    => 'unique_number_2',
					'type'  => 'number',
					'title' => 'Number with Description',
					'desc'  => 'Lets write some description for this number field.',
				),

				array(
					'id'    => 'unique_number_3',
					'type'  => 'number',
					'title' => 'Number with Help',
					'help'  => 'I am a Tooltip helper. This field important for something.',
				),

				array(
					'id'      => 'unique_number_4',
					'type'    => 'number',
					'title'   => 'Number with Default',
					'default' => '10',
				),

				array(
					'id'         => 'unique_number_5',
					'type'       => 'number',
					'title'      => 'Number with Placeholder',
					'attributes' => array(
						'placeholder' => '25',
					),
				),

				array(
					'id'    => 'unique_number_6',
					'type'  => 'number',
					'title' => 'Number with After Text',
					'after' => ' (px)',
				),

			),
		),

		//
		// Slider Options
		//
		array(
			'name'   => 'slider_options',
			'title'  => 'Slider',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'unique_slider_1',
					'type'  => 'slider',
					'title' => 'Slider',
				),

				array(
					'id'    => 'unique_slider_2',
					'type'  => 'slider',
					'title' => 'Slider with Unit',
					'unit'  => 'px',
				),

				array(
					'id'    => 'unique_slider_3',
					'type'  => 'slider',
					'title' => 'Slider with Unit - Max - Min - Step - Default',
					'min'   => 0,
					'max'   => 100,
					'step'  => 1,
					'unit'  => '%',
				),

				array(
					'id'      => 'unique_slider_4',
					'type'    => 'slider',
					'title'   => 'Slider with Default-75',
					'min'     => 0,
					'max'     => 100,
					'step'    => 1,
					'unit'    => '%',
					'default' => '75',
				),

				array(
					'id'      => 'unique_slider_5',
					'type'    => 'slider',
					'title'   => 'Slider with Description',
					'min'     => 0,
					'max'     => 100,
					'step'    => 1,
					'unit'    => 'em',
					'default' => '25',
					'after'   => '<span class="ovic-text-muted">This is a description of slider</span>',
				),

			),
		),

		//
		// Date
		//
		array(
			'name'   => 'date_options',
			'title'  => 'Date',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'opt-date-1',
					'type'  => 'date',
					'title' => 'Date',
				),

				array(
					'id'       => 'opt-date-2',
					'type'     => 'date',
					'title'    => 'Date with custom settings',
					'settings' => array(
						'dateFormat'      => 'mm/dd/yy',
						'changeMonth'     => true,
						'changeYear'      => true,
						'showWeek'        => true,
						'showButtonPanel' => true,
						'weekHeader'      => 'Week',
						'monthNamesShort' => array( 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ),
						'dayNamesMin'     => array( 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ),
					),
				),

				array(
					'id'      => 'opt-date-3',
					'type'    => 'date',
					'title'   => 'Date with From &amp; To',
					'from_to' => true,
				),

				array(
					'id'        => 'opt-date-4',
					'type'      => 'date',
					'title'     => 'Date with custom texts Begin &amp; End',
					'from_to'   => true,
					'text_from' => 'Begin',
					'text_to'   => 'End',
				),

			),
		),

		//
		// Border
		//
		array(
			'name'   => 'border_options',
			'title'  => 'Border',
			'icon'   => 'fa fa-check',
			'fields' => array(
				array(
					'id'    => 'opt-border-1',
					'type'  => 'border',
					'title' => 'Border',
				),

				array(
					'id'      => 'opt-border-2',
					'type'    => 'border',
					'title'   => 'Border with default',
					'default' => array(
						'top'    => '4',
						'right'  => '8',
						'bottom' => '4',
						'left'   => '8',
						'style'  => 'dashed',
						'color'  => '#1e73be',
					),
				),

				array(
					'id'     => 'opt-border-3',
					'type'   => 'border',
					'title'  => 'Border with only left and right',
					'top'    => false,
					'bottom' => false,
				),

				array(
					'id'    => 'opt-border-4',
					'type'  => 'border',
					'title' => 'Border with only top and bottom',
					'left'  => false,
					'right' => false,
				),

				array(
					'id'    => 'opt-border-5',
					'type'  => 'border',
					'title' => 'Border with all directions',
					'all'   => true,
				),
			),
		),

		//
		// Spacing
		//
		array(
			'name'   => 'spacing_options',
			'title'  => 'Spacing',
			'icon'   => 'fa fa-check',
			'fields' => array(
				array(
					'id'    => 'opt-spacing-1',
					'type'  => 'spacing',
					'title' => 'Spacing',
				),

				array(
					'id'      => 'opt-spacing-2',
					'type'    => 'spacing',
					'title'   => 'Spacing with default',
					'default' => array(
						'top'    => '50',
						'right'  => '100',
						'bottom' => '50',
						'left'   => '100',
						'unit'   => 'px',
					),
				),

				array(
					'id'     => 'opt-spacing-3',
					'type'   => 'spacing',
					'title'  => 'Spacing with only left and right',
					'top'    => false,
					'bottom' => false,
				),

				array(
					'id'    => 'opt-spacing-4',
					'type'  => 'spacing',
					'title' => 'Spacing with only top and bottom',
					'left'  => false,
					'right' => false,
				),

				array(
					'id'    => 'opt-spacing-5',
					'type'  => 'spacing',
					'title' => 'Spacing with all directions',
					'all'   => true,
				),
			),
		),

		//
		// Icons
		//
		array(
			'name'   => 'icon_options',
			'title'  => 'Icons',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'unique_icon_1',
					'type'  => 'icon',
					'title' => 'Icon',
				),

				array(
					'id'    => 'unique_icon_2',
					'type'  => 'icon',
					'title' => 'Icon with Description',
					'desc'  => 'Lets write some description for this icon field.',
				),

				array(
					'id'    => 'unique_icon_3',
					'type'  => 'icon',
					'title' => 'Icon with Help',
					'help'  => 'I am a Tooltip helper. This field important for something.',
				),

				array(
					'id'      => 'unique_icon_4',
					'type'    => 'icon',
					'title'   => 'Icon with Default',
					'default' => 'fa fa-check',
				),

				array(
					'id'    => 'unique_icon_5',
					'type'  => 'icon',
					'title' => 'Icon with After Text',
					'after' => '<p>Lets write some description for this icon field.</p>',
				),

			),
		),

		//
		// Group
		//
		array(
			'name'   => 'group_options',
			'title'  => 'Group',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'              => 'unique_group_1',
					'type'            => 'group',
					'title'           => 'Group',
					'button_title'    => 'Add New',
					'accordion_title' => 'Add New Field',
					'fields'          => array(

						array(
							'id'        => 'unique_group_1_text',
							'type'      => 'text',
							'title'     => 'Text Field',
							'multilang' => true,
						),

						array(
							'id'        => 'unique_group_1_switcher',
							'type'      => 'switcher',
							'title'     => 'Switcher Field',
							'multilang' => true,
						),

						array(
							'id'        => 'unique_group_1_textarea',
							'type'      => 'textarea',
							'title'     => 'Textarea Field',
							'multilang' => true,
						),

					),
				),

				array(
					'id'              => 'unique_group_2',
					'type'            => 'group',
					'title'           => 'Group Field with Default',
					'button_title'    => 'Add New',
					'accordion_title' => 'Add New Field',
					'fields'          => array(

						array(
							'id'             => 'opt-typography-3',
							'type'           => 'typography',
							'title'          => 'Typography with few features',
							'text_align'     => true,
							'text_transform' => true,
							'font_size'      => true,
							'line_height'    => true,
							'letter_spacing' => true,
							'color'          => true,
							'default'        => array(
								'font-family' => 'Lato',
								'font-weight' => '900',
								'subset'      => 'latin',
								'type'        => 'google',
							),
						),

						array(
							'id'    => 'unique_group_2_text',
							'type'  => 'text',
							'title' => 'Text Field',
						),

						array(
							'id'    => 'unique_group_2_switcher',
							'type'  => 'switcher',
							'title' => 'Switcher Field',
						),

						array(
							'id'         => 'unique_group_2_textarea',
							'type'       => 'textarea',
							'title'      => 'Textarea Field',
							'dependency' => array( 'unique_group_2_switcher', '==', 'true' ),
						),

					),
					'default'         => array(
						array(
							'unique_group_2_text'     => 'Some text',
							'unique_group_2_switcher' => true,
							'unique_group_2_textarea' => 'Some content',
						),
						array(
							'unique_group_2_text'     => 'Some text 2',
							'unique_group_2_switcher' => true,
							'unique_group_2_textarea' => 'Some content 2',
						),
					),
				),

				array(
					'id'              => 'unique_group_3',
					'type'            => 'group',
					'title'           => 'Group Field',
					'info'            => 'You can use any option field on group',
					'button_title'    => 'Add New Something',
					'accordion_title' => 'Adding New Thing',
					'fields'          => array(

						array(
							'id'    => 'unique_group_3_text',
							'type'  => 'upload',
							'title' => 'Text Field',
						),

					),
				),

				array(
					'id'              => 'unique_group_4',
					'type'            => 'group',
					'title'           => 'Group Field',
					'desc'            => 'Accordion title using the ID of the field, for eg. "Text Field 2" using as accordion title here.',
					'button_title'    => 'Add New',
					'accordion_title' => 'unique_group_4_text_2',
					'fields'          => array(

						array(
							'id'    => 'unique_group_4_text_1',
							'type'  => 'text',
							'title' => 'Text Field 1',
						),

						array(
							'id'    => 'unique_group_4_text_2',
							'type'  => 'text',
							'title' => 'Text Field 2',
						),

						array(
							'id'    => 'unique_group_4_text_3',
							'type'  => 'text',
							'title' => 'Text Field 3',
						),

					),
				),

			),
		),

		//
		// Repeater
		//
		array(
			'name'   => 'repeater_options',
			'title'  => 'Repeater',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'     => 'unique_repeater_1',
					'type'   => 'repeater',
					'title'  => 'Repeater',
					'fields' => array(

						array(
							'id'    => 'unique_repeater_1_text',
							'type'  => 'text',
							'title' => 'Text',
						),

					),
				),

				array(
					'id'           => 'unique_repeater_2',
					'type'         => 'repeater',
					'title'        => 'Repeater with Default',
					'button_title' => 'Add More',
					'fields'       => array(

						array(
							'id'             => 'opt-typography-3',
							'type'           => 'typography',
							'title'          => 'Typography with few features',
							'text_align'     => true,
							'text_transform' => true,
							'font_size'      => true,
							'line_height'    => true,
							'letter_spacing' => true,
							'color'          => true,
							'default'        => array(
								'font-family' => 'Lato',
								'font-weight' => '900',
								'subset'      => 'latin',
								'type'        => 'google',
							),
						),

						array(
							'id'    => 'unique_repeater_2_text',
							'type'  => 'text',
							'title' => 'Text',
						),

						array(
							'id'    => 'unique_repeater_2_switcher',
							'type'  => 'switcher',
							'title' => 'Switcher Field',
						),

						array(
							'id'         => 'unique_repeater_2_textarea',
							'type'       => 'textarea',
							'title'      => 'Textarea Field',
							'dependency' => array( 'unique_repeater_2_switcher', '==', 'true' ),
						),

					),
					'default'      => array(
						array(
							'unique_repeater_2_text' => 'Text 1',
						),
						array(
							'unique_repeater_2_text' => 'Text 2',
						),
					),
				),

				array(
					'id'           => 'unique_repeater_3',
					'type'         => 'repeater',
					'title'        => 'Repeater with Limit 3',
					'limit'        => 3,
					'button_title' => 'Add Image',
					'fields'       => array(

						array(
							'id'    => 'unique_repeater_3_upload',
							'type'  => 'upload',
							'title' => 'Upload',
						),

					),
				),

				array(
					'id'     => 'unique_repeater_4',
					'type'   => 'repeater',
					'title'  => 'Repeater with Multiple Options',
					'fields' => array(

						array(
							'id'    => 'unique_repeater_4_text',
							'type'  => 'text',
							'title' => 'Text 1',
						),

						array(
							'id'    => 'unique_repeater_4_textarea',
							'type'  => 'textarea',
							'title' => 'Text 2',
						),

						array(
							'id'    => 'unique_repeater_4_upload',
							'type'  => 'upload',
							'title' => 'Upload',
						),

					),
				),

			),
		),

		//
		// Accordion
		//
		array(
			'name'   => 'accordion_options',
			'title'  => 'Accordion',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'         => 'unique_accordion_1',
					'type'       => 'accordion',
					'title'      => 'Accordion',
					'accordions' => array(

						array(
							'title'  => 'Accordion 1',
							'fields' => array(

								array(
									'id'             => 'opt-typography-3',
									'type'           => 'typography',
									'title'          => 'Typography with few features',
									'text_align'     => true,
									'text_transform' => true,
									'font_size'      => true,
									'line_height'    => true,
									'letter_spacing' => true,
									'color'          => true,
									'default'        => array(
										'font-family' => 'Lato',
										'font-weight' => '900',
										'subset'      => 'latin',
										'type'        => 'google',
									),
								),

								array(
									'id'    => 'unique_accordion_1_text',
									'type'  => 'text',
									'title' => 'Text Field',
								),

								array(
									'id'    => 'unique_accordion_1_switcher',
									'type'  => 'switcher',
									'title' => 'Switcher Field',
								),

								array(
									'id'         => 'unique_accordion_1_textarea',
									'type'       => 'textarea',
									'title'      => 'Textarea Field',
									'dependency' => array( 'unique_accordion_1_switcher', '==', 'true' ),
								),

							),
						),

						array(
							'title'  => 'Accordion 2',
							'fields' => array(

								array(
									'id'    => 'unique_accordion_2_text',
									'type'  => 'text',
									'title' => 'Text Field',
								),

								array(
									'id'    => 'unique_accordion_2_color',
									'type'  => 'color',
									'title' => 'Color Picker Field',
								),

							),
						),

					),
				),

				array(
					'id'         => 'unique_accordion_fields_2',
					'type'       => 'accordion',
					'title'      => 'Accordion Field with Default',
					'accordions' => array(

						array(
							'title'  => 'Fields 1',
							'fields' => array(

								array(
									'id'      => 'unique_accordion_fields_2_text',
									'type'    => 'text',
									'title'   => 'Text Field',
									'default' => 'This is default text bla bla bla',
								),

								array(
									'id'      => 'unique_accordion_fields_2_textarea',
									'type'    => 'textarea',
									'title'   => 'Textarea Field',
									'default' => 'This is default textarea content bla bla bla',
								),

							),
						),

						array(
							'title'  => 'Fields 2',
							'fields' => array(

								array(
									'id'      => 'unique_accordion_fields_2_color',
									'type'    => 'color',
									'title'   => 'Color Picker Field',
									'default' => '#1e73be',
								),

							),
						),

						array(
							'title'  => 'Fields 3',
							'fields' => array(

								array(
									'id'      => 'unique_accordion_fields_3_color',
									'type'    => 'color',
									'title'   => 'Color Picker Field',
									'default' => '#ffbc00',
								),

							),
						),

					),
				),

				array(
					'id'         => 'unique_accordion_3',
					'type'       => 'accordion',
					'accordions' => array(

						array(
							'title'  => 'Other 1',
							'fields' => array(

								array(
									'id'    => 'unique_accordion_other_1_text',
									'type'  => 'text',
									'title' => 'Text Field',
								),

							),
						),

						array(
							'title'  => 'Other 2',
							'fields' => array(

								array(
									'id'    => 'unique_accordion_other_2_text',
									'type'  => 'text',
									'title' => 'Text Field',
								),

							),
						),

					),
				),

			),
		),

		//
		// Upload
		//
		array(
			'name'   => 'upload_options',
			'title'  => 'Upload',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'unique_upload_1',
					'type'  => 'upload',
					'title' => 'Upload',
				),

				array(
					'id'      => 'unique_upload_2',
					'type'    => 'upload',
					'title'   => 'Upload with Preview',
					'preview' => true,
				),

				array(
					'id'    => 'unique_upload_3',
					'type'  => 'upload',
					'title' => 'Upload with Description',
					'desc'  => 'Lets write some description for this upload.',
				),

				array(
					'id'    => 'unique_upload_4',
					'type'  => 'upload',
					'title' => 'Upload with Help',
					'help'  => 'I am a Tooltip helper. This field important for something.',
				),

				array(
					'id'      => 'unique_upload_5',
					'type'    => 'upload',
					'title'   => 'Upload with Default',
					'default' => 'screenshot-1.png',
				),

				array(
					'id'    => 'unique_upload_6',
					'type'  => 'upload',
					'title' => 'Upload with After Text',
					'after' => '<p>You can use default value <strong>get_template_directory_uri()</strong>."/images/screenshot-1.png"</p>',
				),

				array(
					'id'         => 'unique_upload_7',
					'type'       => 'upload',
					'title'      => 'Upload with Placeholder',
					'attributes' => array(
						'placeholder' => 'https://',
					),
				),

				array(
					'id'       => 'unique_upload_8',
					'type'     => 'upload',
					'title'    => 'Upload with Custom Title',
					'settings' => array(
						'button_title' => 'Upload Logo',
						'frame_title'  => 'Choose a image',
						'insert_title' => 'Use this image',
					),
				),

				array(
					'id'       => 'unique_upload_9',
					'type'     => 'upload',
					'title'    => 'Upload with Video',
					'settings' => array(
						'upload_type'  => 'video',
						'button_title' => 'Upload Video',
						'frame_title'  => 'Choose a Video',
						'insert_title' => 'Use This Video',
					),
				),

			),
		),

		//
		// Button Set
		//
		array(
			'name'   => 'button_set_options',
			'title'  => 'Button Set',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'      => 'opt-button-set-1',
					'type'    => 'button_set',
					'title'   => 'Button Set',
					'options' => array(
						'enabled'  => 'Enabled',
						'disabled' => 'Disabled',
					),
				),

				array(
					'id'      => 'opt-button-set-2',
					'type'    => 'button_set',
					'title'   => 'Button Set with default',
					'options' => array(
						'enabled'  => 'Enabled',
						'default'  => 'Disabled',
						'disabled' => 'Disabled',
					),
					'default' => 'default',
				),

				array(
					'id'      => 'opt-button-set-3',
					'type'    => 'button_set',
					'title'   => 'Button Set',
					'options' => array(
						'activate'   => 'Activate',
						'deactivate' => 'Deactivate',
					),
					'default' => 'activate',
				),

				array(
					'id'      => 'opt-button-set-4',
					'type'    => 'button_set',
					'title'   => 'Button Set',
					'options' => array(
						'on'  => 'ON',
						'off' => 'OFF',
					),
					'default' => 'on',
				),

				array(
					'id'       => 'opt-button-set-5',
					'type'     => 'button_set',
					'title'    => 'Button Set with multiple choice',
					'multiple' => true,
					'options'  => array(
						'opt-1' => 'Option 1',
						'opt-2' => 'Option 2',
						'opt-3' => 'Option 3',
						'opt-4' => 'Option 4',
						'opt-5' => 'Option 5',
					),
				),

				array(
					'id'       => 'opt-button-set-6',
					'type'     => 'button_set',
					'title'    => 'Button Set with multiple choice and default',
					'multiple' => true,
					'options'  => array(
						'opt-1' => 'Option 1',
						'opt-2' => 'Option 2',
						'opt-3' => 'Option 3',
						'opt-4' => 'Option 4',
						'opt-5' => 'Option 5',
					),
					'default'  => array( 'opt-2', 'opt-4' ),
				),

			),
		),

		//
		// Background
		//
		array(
			'name'   => 'background_options',
			'title'  => 'Background',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'opt-background-1',
					'type'  => 'background',
					'title' => 'Background',
				),

				array(
					'id'      => 'opt-background-2',
					'type'    => 'background',
					'title'   => 'Background with default',
					'default' => array(
						'background-color'      => '#e80000',
						'background-position'   => 'center center',
						'background-repeat'     => 'repeat-x',
						'background-attachment' => 'fixed',
						'background-size'       => 'cover',
					),
				),

				array(
					'id'                    => 'opt-background-3',
					'type'                  => 'background',
					'title'                 => 'Background with all features',
					'background_color'      => true,
					'background_image'      => true,
					'background-position'   => true,
					'background_repeat'     => true,
					'background_attachment' => true,
					'background_size'       => true,
					'background_origin'     => true,
					'background_clip'       => true,
					'background_blend_mode' => true,
					'background_gradient'   => true,
					'default'               => array(
						'background-color'              => '#009e44',
						'background-gradient-color'     => '#81d742',
						'background-gradient-direction' => '135deg',
						'background-position'           => 'center center',
						'background-repeat'             => 'repeat-x',
						'background-attachment'         => 'fixed',
						'background-size'               => 'cover',
						'background-origin'             => 'border-box',
						'background-clip'               => 'padding-box',
						'background-blend-mode'         => 'normal',
					),
				),

			),
		),

		//
		// Color Picker
		//
		array(
			'name'   => 'link_color_options',
			'title'  => 'Link Color',
			'icon'   => 'fa fa-check',
			'fields' => array(
				array(
					'id'    => 'opt-link-color-1',
					'type'  => 'link_color',
					'title' => 'Link Color',
				),

				array(
					'id'      => 'opt-link-color-2',
					'type'    => 'link_color',
					'title'   => 'Link Color with default',
					'default' => array(
						'color' => '#1e73be',
						'hover' => '#259ded',
					),
				),

				array(
					'id'      => 'opt-link-color-3',
					'type'    => 'link_color',
					'title'   => 'Link Color with more color options',
					'color'   => true,
					'hover'   => true,
					'visited' => true,
					'active'  => true,
					'focus'   => true,
				),
			),
		),
		array(
			'name'   => 'palette_options',
			'title'  => 'Color Palette',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'       => 'opt-palette-1',
					'type'     => 'palette',
					'title'    => 'Palette',
					'subtitle' => 'Three set colors',
					'options'  => array(
						'set-1' => array( '#f36e27', '#f3d430', '#ed1683' ),
						'set-2' => array( '#4153ab', '#6e86c7', '#211f27' ),
						'set-3' => array( '#162526', '#508486', '#C8C6CE' ),
						'set-4' => array( '#ccab5e', '#fff55f', '#197c5d' ),
					),
					'default'  => 'set-1',
				),

				array(
					'id'       => 'opt-palette-1',
					'type'     => 'palette',
					'title'    => 'Palette',
					'subtitle' => 'Four set colors',
					'options'  => array(
						'set-1' => array( '#f04e36', '#f36e27', '#f3d430', '#ed1683' ),
						'set-2' => array( '#f9ca06', '#b5b546', '#2f4d48', '#212b2f' ),
						'set-3' => array( '#4153ab', '#6e86c7', '#211f27', '#d69762' ),
						'set-4' => array( '#162526', '#508486', '#C8C6CE', '#B45F1A' ),
						'set-5' => array( '#bbd5ff', '#ccab5e', '#fff55f', '#197c5d' ),
					),
					'default'  => 'set-3',
				),

				array(
					'id'       => 'opt-palette-2',
					'type'     => 'palette',
					'title'    => 'Palette',
					'subtitle' => 'Five set colors',
					'options'  => array(
						'set-1' => array( '#bbd5ff', '#ccab5e', '#fff55f', '#197c5d', '#bce2c4' ),
						'set-2' => array( '#6d3264', '#edf7f6', '#fde8e9', '#006675', '#e49ab0' ),
						'set-3' => array( '#000100', '#002642', '#ffce4b', '#ff595e', '#0052cc' ),
					),
					'default'  => 'set-1',
				),

			),
		),

		//
		// Color
		//
		array(
			'name'   => 'color_options',
			'title'  => 'Color',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'opt-color-1',
					'type'  => 'color',
					'title' => 'Color',
				),

				array(
					'id'      => 'opt-color-2',
					'type'    => 'color',
					'title'   => 'Color with default (hex)',
					'default' => '#3498db',
				),

				array(
					'id'      => 'opt-color-3',
					'type'    => 'color',
					'title'   => 'Color with default (rgba)',
					'default' => 'rgba(255,255,0,0.25)',
				),

				array(
					'id'      => 'opt-color-4',
					'type'    => 'color',
					'title'   => 'Color with default (transparent)',
					'default' => 'transparent',
				),

				array(
					'id'      => 'opt-color-group-1',
					'type'    => 'color_group',
					'title'   => 'Color Group',
					'options' => array(
						'color-1' => 'Color 1',
						'color-2' => 'Color 2',
					),
				),

				array(
					'id'      => 'opt-color-group-2',
					'type'    => 'color_group',
					'title'   => 'Color Group',
					'options' => array(
						'color-1' => 'Color 1',
						'color-2' => 'Color 2',
						'color-3' => 'Color 3',
					),
				),

				array(
					'id'       => 'opt-color-group-3',
					'type'     => 'color_group',
					'title'    => 'Color Group with default',
					'subtitle' => 'Can be add unlimited color options.',
					'options'  => array(
						'color-1' => 'Color 1',
						'color-2' => 'Color 2',
						'color-3' => 'Color 3',
						'color-4' => 'Color 4',
						'color-5' => 'Color 5',
					),
					'default'  => array(
						'color-1' => '#000100',
						'color-2' => '#002642',
						'color-3' => '#ffce4b',
						'color-4' => '#ff595e',
						'color-5' => '#0052cc',
					),
				),

			),
		),

		//
		// Image Select
		//
		array(
			'name'   => 'image_select_options',
			'title'  => 'Image Select',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'      => 'opt-image-select-1',
					'type'    => 'image_select',
					'title'   => 'Image Select',
					'options' => array(
						'opt-1' => 'https://codestarframework.com/assets/images/placeholder/150x125-2ecc71.gif',
						'opt-2' => 'https://codestarframework.com/assets/images/placeholder/150x125-e74c3c.gif',
						'opt-3' => 'https://codestarframework.com/assets/images/placeholder/150x125-ffbc00.gif',
						'opt-4' => 'https://codestarframework.com/assets/images/placeholder/150x125-3498db.gif',
					),
				),

				array(
					'id'      => 'opt-image-select-2',
					'type'    => 'image_select',
					'title'   => 'Image Select with default',
					'options' => array(
						'opt-1' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-2' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-3' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-4' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-5' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-6' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-7' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
					),
					'default' => 'opt-4',
				),

				array(
					'id'       => 'opt-image-select-3',
					'type'     => 'image_select',
					'title'    => 'Image Select with multiple choice',
					'multiple' => true,
					'options'  => array(
						'opt-1' => 'https://codestarframework.com/assets/images/placeholder/80x80-e74c3c.gif',
						'opt-2' => 'https://codestarframework.com/assets/images/placeholder/80x80-ffbc00.gif',
						'opt-3' => 'https://codestarframework.com/assets/images/placeholder/80x80-3498db.gif',
						'opt-4' => 'https://codestarframework.com/assets/images/placeholder/80x80-2ecc71.gif',
					),
				),

				array(
					'id'       => 'opt-image-select-4',
					'type'     => 'image_select',
					'title'    => 'Image Select with multiple choice and default',
					'multiple' => true,
					'options'  => array(
						'opt-1' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-2' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-3' => 'https://codestarframework.com/assets/images/placeholder/80x80-e74c3c.gif',
						'opt-4' => 'https://codestarframework.com/assets/images/placeholder/80x80-ffbc00.gif',
						'opt-5' => 'https://codestarframework.com/assets/images/placeholder/80x80-3498db.gif',
						'opt-6' => 'https://codestarframework.com/assets/images/placeholder/80x80-2ecc71.gif',
						'opt-7' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
						'opt-8' => 'https://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
					),
					'default'  => array( 'opt-3', 'opt-4', 'opt-5', 'opt-6' ),
				),

			),
		),

		//
		// Typography
		//
		array(
			'name'   => 'typography_options',
			'title'  => 'Typography',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'     => 'opt-typography-1',
					'type'   => 'typography',
					'title'  => 'Typography',
					'output' => 'body',
				),

				array(
					'id'      => 'opt-typography-2',
					'type'    => 'typography',
					'title'   => 'Typography with default',
					'default' => array(
						'font-family'    => 'Barlow',
						'font-weight'    => '600',
						'subset'         => 'latin-ext',
						'type'           => 'google',
						'text-align'     => 'center',
						'text-transform' => 'capitalize',
						'font-size'      => '18',
						'line-height'    => '20',
						'letter-spacing' => '-1',
						'color'          => '#009e44',
					),
				),

				array(
					'id'             => 'opt-typography-3',
					'type'           => 'typography',
					'title'          => 'Typography with few features',
					'text_align'     => false,
					'text_transform' => false,
					'font_size'      => false,
					'line_height'    => false,
					'letter_spacing' => false,
					'color'          => false,
					'default'        => array(
						'font-family' => 'Lato',
						'font-weight' => '900',
						'subset'      => 'latin',
						'type'        => 'google',
					),
				),

				array(
					'id'                 => 'opt-typography-4',
					'type'               => 'typography',
					'title'              => 'Typography with all features',
					'font_family'        => true,
					'font_weight'        => true,
					'font_style'         => true,
					'font_size'          => true,
					'line_height'        => true,
					'letter_spacing'     => true,
					'text_align'         => true,
					'text-transform'     => true,
					'color'              => true,
					'subset'             => true,
					'backup_font_family' => true,
					'font_variant'       => true,
					'word_spacing'       => true,
					'text_decoration'    => true,
					'default'            => array(
						'font-family' => 'Old Standard TT',
						'type'        => 'google',
					),
				),

			),
		),

		//
		// Wysiwyg
		//
		array(
			'name'   => 'wp_editor_options',
			'title'  => 'WP Editor',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'opt-wp-editor-1',
					'type'  => 'wp_editor',
					'title' => 'WP Editor',
				),

				array(
					'id'            => 'opt-wp-editor-2',
					'type'          => 'wp_editor',
					'title'         => 'WP Editor with Custom Height and No Media Buttons',
					'subtitle'      => 'Settings: height => 100px, media_buttons => false',
					'height'        => '100px',
					'media_buttons' => false,
				),

				array(
					'id'            => 'opt-wp-editor-3',
					'type'          => 'wp_editor',
					'title'         => 'WP Editor without QuickTags and Media Buttons',
					'subtitle'      => 'Settings: height => 100px, media_buttons => false, quicktags => false',
					'height'        => '100px',
					'media_buttons' => false,
					'quicktags'     => false,
				),

				array(
					'id'            => 'opt-wp-editor-4',
					'type'          => 'wp_editor',
					'title'         => 'WP Editor without Tinymce and Media Buttons',
					'subtitle'      => 'Settings: height => 100px, media_buttons => false, tinymce => false',
					'height'        => '100px',
					'media_buttons' => false,
					'tinymce'       => false,
				),

			),
		),

		//
		// Image
		//
		array(
			'name'   => 'image_options',
			'title'  => 'Image',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'image_1',
					'type'  => 'image',
					'title' => 'Image',
				),

				array(
					'id'    => 'image_2',
					'type'  => 'image',
					'title' => 'Image with Description and Help',
					'desc'  => 'Lets write some description for this image field.',
					'help'  => 'This option field is useful. You will love it!',
				),

				array(
					'id'        => 'image_3',
					'type'      => 'image',
					'title'     => 'Image with Custom Button Title',
					'add_title' => 'Add Logo',
				),

			),
		),

		//
		// Media
		//
		array(
			'name'   => 'media_options',
			'title'  => 'media',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'        => 'opt-media-1',
					'type'      => 'media',
					'title'     => 'Media',
					'multilang' => true,
				),

				array(
					'id'      => 'opt-media-2',
					'type'    => 'media',
					'title'   => 'Media without preview',
					'preview' => false,
				),

				array(
					'id'      => 'opt-media-3',
					'type'    => 'media',
					'title'   => 'Media without url',
					'preview' => false,
				),

				array(
					'id'      => 'opt-media-4',
					'type'    => 'media',
					'title'   => 'Media with only image type',
					'library' => 'image',
				),

				array(
					'id'      => 'opt-media-5',
					'type'    => 'media',
					'title'   => 'Media with only video type',
					'library' => 'video',
				),

			),
		),

		//
		// Gallery
		//
		array(
			'name'   => 'gallery_options',
			'title'  => 'Gallery',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'gallery_1',
					'type'  => 'gallery',
					'title' => 'Gallery',
				),

				array(
					'id'          => 'gallery_2',
					'type'        => 'gallery',
					'title'       => 'Gallery with Custom Title',
					'add_title'   => 'Add Images',
					'edit_title'  => 'Edit Images',
					'clear_title' => 'Remove Images',
				),

				array(
					'id'          => 'gallery_3',
					'type'        => 'gallery',
					'title'       => 'Gallery with Custom Button Titles',
					'desc'        => 'Lets write some description for this image field.',
					'help'        => 'This option field is useful. You will love it!',
					'add_title'   => 'Add Image(s)',
					'edit_title'  => 'Edit Image(s)',
					'clear_title' => 'Clear Image(s)',
				),

			),
		),

		//
		// Sortable
		//
		array(
			'name'   => 'sortable_options',
			'title'  => 'Sortable',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'     => 'opt-sortable-1',
					'type'   => 'sortable',
					'title'  => 'Sortable',
					'fields' => array(
						array(
							'id'    => 'opt-text-1',
							'type'  => 'text',
							'title' => 'Text 1',
						),
						array(
							'id'    => 'opt-text-2',
							'type'  => 'text',
							'title' => 'Text 2',
						),
						array(
							'id'    => 'opt-text-3',
							'type'  => 'text',
							'title' => 'Text 3',
						),
					),
				),

				array(
					'id'      => 'opt-sortable-2',
					'type'    => 'sortable',
					'title'   => 'Sortable with default',
					'fields'  => array(
						array(
							'id'    => 'opt-text-1',
							'type'  => 'text',
							'title' => 'Text 1',
						),
						array(
							'id'    => 'opt-text-2',
							'type'  => 'text',
							'title' => 'Text 2',
						),
						array(
							'id'    => 'opt-text-3',
							'type'  => 'text',
							'title' => 'Text 3',
						),
					),
					'default' => array(
						'opt-text-1' => 'This is text 1 default',
						'opt-text-2' => 'This is text 2 default',
						'opt-text-3' => 'This is text 3 default',
					),
				),

			),
		),

		//
		// Sorter
		//
		array(
			'name'   => 'sorter_options',
			'title'  => 'Sorter',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'      => 'opt-sorter-1',
					'type'    => 'sorter',
					'title'   => 'Sorter',
					'default' => array(
						'enabled'  => array(
							'opt-1' => 'Option 1',
							'opt-2' => 'Option 2',
							'opt-3' => 'Option 3',
						),
						'disabled' => array(
							'opt-4' => 'Option 4',
							'opt-5' => 'Option 5',
						),
					),
				),

				array(
					'id'             => 'opt-sorter-2',
					'type'           => 'sorter',
					'title'          => 'Sorter with custom title',
					'enabled_title'  => 'Activated',
					'disabled_title' => 'Deactivated',
					'default'        => array(
						'enabled'  => array(
							'opt-1' => 'Option 1',
							'opt-2' => 'Option 2',
							'opt-3' => 'Option 3',
						),
						'disabled' => array(
							'opt-4' => 'Option 4',
							'opt-5' => 'Option 5',
						),
					),
				),

				array(
					'id'            => 'opt-sorter-3',
					'type'          => 'sorter',
					'title'         => 'Sorter with use only enabled section and without title',
					'enabled_title' => false,
					'disabled'      => false,
					'default'       => array(
						'enabled' => array(
							'opt-1' => 'Option 1',
							'opt-2' => 'Option 2',
							'opt-3' => 'Option 3',
						),
					),
				),

			),
		),

		//
		// Fieldset
		//
		array(
			'name'   => 'fieldset_options',
			'title'  => 'Fieldset',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'     => 'fieldset_1',
					'type'   => 'fieldset',
					'title'  => 'Fieldset',
					'fields' => array(

						array(
							'id'    => 'fieldset_1_text',
							'type'  => 'text',
							'title' => 'Text Field',
						),

						array(
							'id'    => 'fieldset_1_upload',
							'type'  => 'upload',
							'title' => 'Upload Field',
						),

						array(
							'id'    => 'fieldset_1_textarea',
							'type'  => 'textarea',
							'title' => 'Textarea Field',
						),

					),
				),

				array(
					'id'      => 'fieldset_2',
					'type'    => 'fieldset',
					'title'   => 'Fieldset with Default',
					'fields'  => array(

						array(
							'type'    => 'subheading',
							'content' => 'Title of Fieldset',
						),

						array(
							'id'    => 'fieldset_2_text',
							'type'  => 'text',
							'title' => 'Text Field',
						),

						array(
							'id'    => 'fieldset_2_checkbox',
							'type'  => 'checkbox',
							'title' => 'Checkbox Field',
							'label' => 'Are you sure?',
						),

						array(
							'id'    => 'fieldset_2_textarea',
							'type'  => 'textarea',
							'title' => 'Upload Field',
						),

					),
					'default' => array(
						'fieldset_2_text'     => 'Hello',
						'fieldset_2_checkbox' => true,
						'fieldset_2_textarea' => 'Do stuff',
					),
				),

			),
		),

		//
		// Tabbed
		//
		array(
			'name'   => 'tabbed_options',
			'title'  => 'Tabbed',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'    => 'opt-tabbed-1',
					'type'  => 'tabbed',
					'title' => 'Tabbed',
					'tabs'  => array(

						array(
							'title'  => 'Tab 1',
							'fields' => array(
								array(
									'id'    => 'opt-text-1',
									'type'  => 'text',
									'title' => 'Text 1',
								),
								array(
									'id'    => 'opt-textarea-1',
									'type'  => 'textarea',
									'title' => 'Textarea 1',
								),
							),
						),

						array(
							'title'  => 'Tab 2',
							'fields' => array(
								array(
									'id'    => 'opt-text-2',
									'type'  => 'text',
									'title' => 'Text 2',
								),
								array(
									'id'    => 'opt-textarea-2',
									'type'  => 'textarea',
									'title' => 'Textarea 2',
								),
							),
						),

					),
				),

				array(
					'id'      => 'opt-tabbed-2',
					'type'    => 'tabbed',
					'title'   => 'Tabbed with default and icons',
					'tabs'    => array(
						array(
							'title'  => 'Fields 1',
							'icon'   => 'fa fa-check',
							'fields' => array(
								array(
									'id'    => 'opt-text-1',
									'type'  => 'text',
									'title' => 'Text 1',
								),
								array(
									'id'    => 'opt-text-2',
									'type'  => 'text',
									'title' => 'Text 2',
								),
							),
						),
						array(
							'title'  => 'Fields 2',
							'icon'   => 'fa fa-star',
							'fields' => array(
								array(
									'id'    => 'opt-color-1',
									'type'  => 'color',
									'title' => 'Color 1',
								),
								array(
									'id'    => 'opt-color-2',
									'type'  => 'color',
									'title' => 'Color 2',
								),
							),
						),
						array(
							'title'  => 'Fields 3',
							'icon'   => 'fa fa-gear',
							'fields' => array(
								array(
									'id'    => 'opt-textarea-1',
									'type'  => 'textarea',
									'title' => 'Textarea 1',
								),
								array(
									'id'    => 'opt-textarea-2',
									'type'  => 'textarea',
									'title' => 'Textarea 2',
								),
							),
						),
					),
					'default' => array(
						'opt-text-1'     => 'This is text 1 default value',
						'opt-text-2'     => 'This is text 2 default value',
						'opt-color-1'    => '#1e73be',
						'opt-color-2'    => '#ffbc00',
						'opt-textarea-1' => 'This is textarea 1 default value',
						'opt-textarea-2' => 'This is textarea 2 default value',
					),
				),

			),
		),

		//
		// Ace Editor
		//
		array(
			'name'   => 'ace_editor_options',
			'title'  => 'Ace Editor',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'id'       => 'opt-code-editor-1',
					'type'     => 'code_editor',
					'title'    => 'Code Editor',
					'subtitle' => '<strong>Default Editor</strong> Using: theme: default and mode: htmlmixed',
				),

				array(
					'id'       => 'code_editor_2',
					'type'     => 'code_editor',
					'title'    => 'Code Editor',
					'subtitle' => '<strong>HTML Editor</strong> Using: theme: shadowfox and mode: htmlmixed',
					'settings' => array(
						'theme' => 'shadowfox',
						'mode'  => 'htmlmixed',
					),
					'default'  => '<div class="wrapper">
  <h1>Hello world</h1>
  <p>Lorem <strong>ipsum</strong> dollar.</p>
</div>',
				),

				array(
					'id'       => 'opt-code-editor-2',
					'type'     => 'code_editor',
					'title'    => 'Code Editor',
					'subtitle' => '<strong>JS Editor</strong> Using: theme: dracula and mode: javascript',
					'settings' => array(
						'theme' => 'dracula',
						'mode'  => 'javascript',
					),
					'default'  => ';(function( $, window, document, undefined ) {
  "use strict";

  $(document).ready( function() {

    // do stuff

  });

})( jQuery, window, document );',
				),

				array(
					'id'       => 'opt-code-editor-3',
					'type'     => 'code_editor',
					'before'   => '<p class="csf-text-muted"><strong>CSS Editor</strong> It shows full width if there is no field of title and using: theme: mbo and mode: css</p>',
					'settings' => array(
						'theme' => 'mbo',
						'mode'  => 'css',
					),
					'default'  => '.wrapper {
  font-family: "Open Sans";
  font-size: 13px;
  width: 250px;
  height: 100px;
  color: #fff;
  background-color: #555;
}',
				),

			),
		),

		//
		// Others
		//
		array(
			'name'   => 'others_options',
			'title'  => 'Others',
			'icon'   => 'fa fa-check',
			'fields' => array(

				array(
					'type'    => 'heading',
					'content' => 'This is a heading field',
				),

				array(
					'type'    => 'subheading',
					'content' => 'This is a subheading field',
				),

				array(
					'type'    => 'content',
					'content' => 'This is a content field',
				),

				array(
					'type'    => 'submessage',
					'style'   => 'success',
					'content' => 'This is a <strong>submessage</strong> field. And using style <strong>success</strong>',
				),

				array(
					'type'    => 'content',
					'content' => 'This is a content field',
				),
				array(
					'type'    => 'submessage',
					'style'   => 'info',
					'content' => 'This is a <strong>submessage</strong> field. And using style <strong>info</strong>',
				),

				array(
					'type'    => 'submessage',
					'style'   => 'warning',
					'content' => 'This is a <strong>submessage</strong> field. And using style <strong>warning</strong>',
				),

				array(
					'type'    => 'submessage',
					'style'   => 'danger',
					'content' => 'This is a <strong>submessage</strong> field. And using style <strong>danger</strong>',
				),

				array(
					'type'    => 'notice',
					'style'   => 'success',
					'content' => 'This is a <strong>notice</strong> field. And using style <strong>success</strong>',
				),

				array(
					'type'    => 'notice',
					'style'   => 'info',
					'content' => 'This is a <strong>notice</strong> field. And using style <strong>info</strong>',
				),

				array(
					'type'    => 'notice',
					'style'   => 'warning',
					'content' => 'This is a <strong>notice</strong> field. And using style <strong>warning</strong>',
				),

				array(
					'type'    => 'notice',
					'style'   => 'danger',
					'content' => 'This is a <strong>notice</strong> field. And using style <strong>danger</strong>',
				),

				array(
					'type'    => 'content',
					'content' => 'This is a <strong>content</strong> field. You can write some contents here.',
				),

				array(
					'id'    => 'unique_others_text_9',
					'type'  => 'text',
					'title' => 'Others Text 9',
					'after' => '<p class="ovic-text-warning">This field using debug=true</p>',
					'debug' => true,
				),

			),
		),

	),
);

//
// Seperator
//
$options[] = array(
	'name'  => 'seperator_1',
	'title' => 'A Seperator',
	'icon'  => 'fa fa-bookmark',
);

//
// Backup
//
$options[] = array(
	'name'   => 'backup_section',
	'title'  => 'Backup',
	'icon'   => 'fa fa-shield',
	'fields' => array(

		array(
			'type'    => 'notice',
			'class'   => 'warning',
			'content' => 'You can save your current options. Download a Backup and Import.',
		),

		array(
			'type' => 'backup',
		),

	),
);

//
// Validate
//
$options[] = array(
	'name'   => 'validate_section',
	'title'  => 'Validate',
	'icon'   => 'fa fa-check-circle',
	'fields' => array(

		array(
			'id'       => 'validate_1',
			'type'     => 'text',
			'title'    => 'Validate Example 1',
			'desc'     => 'This text field only accepted email address.',
			'default'  => 'info@domain.com',
			'validate' => 'ovic_validate_email',
		),

		array(
			'id'       => 'validate_2',
			'type'     => 'text',
			'title'    => 'Validate Example 2',
			'desc'     => 'This text field only accepted numbers',
			'default'  => '123456',
			'validate' => 'ovic_validate_numeric',
		),

		array(
			'id'       => 'validate_3',
			'type'     => 'text',
			'title'    => 'Validate Example 3',
			'after'    => ' <small class="ovic-text-warning">( * required )</small>',
			'default'  => 'lorem ipsum',
			'validate' => 'ovic_validate_required',
		),

	),
);

//
// Sanitize
//
$options[] = array(
	'name'   => 'sanitize_section',
	'title'  => 'Sanitize',
	'icon'   => 'fa fa-repeat',
	'fields' => array(

		array(
			'id'       => 'sanitize_1',
			'type'     => 'text',
			'title'    => 'Sanitize Example 1',
			'after'    => '<p class="ovic-text-muted">This text field using wp core function "sanitize_title". try to write some text</p>',
			'sanitize' => 'sanitize_title',
		),

		array(
			'id'       => 'sanitize_2',
			'type'     => 'text',
			'title'    => 'Sanitize Example 2',
			'after'    => '<p class="ovic-text-muted">This text field using custom function "ovic_sanitize_custom". try to write some text, converting word "a" to "b"</p>',
			'sanitize' => 'ovic_sanitize_custom',
		),

	),
);

//
// Dependencies
//
$options[] = array(
	'name'   => 'dependencies',
	'title'  => 'Dependencies',
	'icon'   => 'fa fa-code-fork',
	'fields' => array(

		array(
			'type'    => 'subheading',
			'content' => 'Basic Dependencies',
		),

		array(
			'id'    => 'dep_1',
			'type'  => 'text',
			'title' => 'If text <u>not be empty</u>',
		),

		array(
			'type'       => 'notice',
			'class'      => 'info',
			'content'    => 'Done, this text option have something.',
			'dependency' => array( 'dep_1', '!=', '' ),
		),

		array(
			'id'    => 'dep_2',
			'type'  => 'switcher',
			'title' => 'If switcher mode <u>ON</u>',
		),

		array(
			'type'       => 'notice',
			'class'      => 'success',
			'content'    => 'Woow! Switcher is ON',
			'dependency' => array( 'dep_2', '==', 'true' ),
		),

		array(
			'id'      => 'dep_3',
			'type'    => 'select',
			'title'   => 'Select color <u>black or white</u>',
			'options' => array(
				'blue'   => 'Blue',
				'yellow' => 'Yellow',
				'green'  => 'Green',
				'black'  => 'Black',
				'white'  => 'White',
			),
		),

		array(
			'type'       => 'notice',
			'class'      => 'danger',
			'content'    => 'Well done!',
			'dependency' => array( 'dep_3', 'any', 'black,white' ),
		),

		array(
			'id'      => 'dep_4',
			'type'    => 'radio',
			'title'   => 'If set <u>No, Thanks</u>',
			'options' => array(
				'yes'      => 'Yes, Please',
				'no'       => 'No, Thanks',
				'not-sure' => 'I am not sure!',
			),
			'default' => 'yes',
		),

		array(
			'type'       => 'notice',
			'class'      => 'info',
			'content'    => 'Uh why?!!!',
			'dependency' => array( 'dep_4_no', '==', 'true' ),
		),

		array(
			'id'      => 'dep_5',
			'type'    => 'checkbox',
			'title'   => 'If checked <u>danger</u>',
			'options' => array(
				'success' => 'Success',
				'danger'  => 'Danger',
				'info'    => 'Info',
				'warning' => 'Warning',
			),
		),

		array(
			'type'       => 'notice',
			'class'      => 'danger',
			'content'    => 'Danger!',
			'dependency' => array( 'dep_5_danger', '==', 'true' ),
		),

		array(
			'id'      => 'dep_6',
			'type'    => 'image_select',
			'title'   => 'If check <u>Blue box</u> (checkbox)',
			'options' => array(
				'green'  => 'https://codestarframework.com/assets/images/placeholder/100x80-2ecc71.gif',
				'red'    => 'https://codestarframework.com/assets/images/placeholder/100x80-e74c3c.gif',
				'yellow' => 'https://codestarframework.com/assets/images/placeholder/100x80-ffbc00.gif',
				'blue'   => 'https://codestarframework.com/assets/images/placeholder/100x80-3498db.gif',
				'gray'   => 'https://codestarframework.com/assets/images/placeholder/100x80-555555.gif',
			),
			'info'    => 'Image select field input="checkbox" model. in checkbox model unselected available.',
		),

		array(
			'type'       => 'notice',
			'class'      => 'info',
			'content'    => 'Blue box selected!',
			'dependency' => array( 'dep_6_blue', '==', 'true' ),
		),

		array(
			'id'         => 'dep_6_alt',
			'type'       => 'image_select',
			'title'      => 'If check <u>Green box or Blue box</u> (checkbox)',
			'options'    => array(
				'green'  => 'https://codestarframework.com/assets/images/placeholder/100x80-2ecc71.gif',
				'red'    => 'https://codestarframework.com/assets/images/placeholder/100x80-e74c3c.gif',
				'yellow' => 'https://codestarframework.com/assets/images/placeholder/100x80-ffbc00.gif',
				'blue'   => 'https://codestarframework.com/assets/images/placeholder/100x80-3498db.gif',
				'gray'   => 'https://codestarframework.com/assets/images/placeholder/100x80-555555.gif',
			),
			'info'       => 'Multipel Image select field input="checkbox" model. in checkbox model unselected available.',
			'default'    => 'gray',
			'attributes' => array(
				'data-depend-id' => 'dep_6_alt',
			),
		),

		array(
			'type'       => 'notice',
			'class'      => 'success',
			'content'    => 'Green or Blue box selected!',
			'dependency' => array( 'dep_6_alt', 'any', 'green,blue' ),
		),

		array(
			'id'      => 'dep_7',
			'type'    => 'image_select',
			'title'   => 'If check <u>Green box</u> (radio)',
			'options' => array(
				'green'  => 'https://codestarframework.com/assets/images/placeholder/100x80-2ecc71.gif',
				'red'    => 'https://codestarframework.com/assets/images/placeholder/100x80-e74c3c.gif',
				'yellow' => 'https://codestarframework.com/assets/images/placeholder/100x80-ffbc00.gif',
				'blue'   => 'https://codestarframework.com/assets/images/placeholder/100x80-3498db.gif',
				'gray'   => 'https://codestarframework.com/assets/images/placeholder/100x80-555555.gif',
			),
			'info'    => 'Image select field input="radio" model. in radio model unselected unavailable.',
			'radio'   => true,
			'default' => 'gray',
		),

		array(
			'type'       => 'notice',
			'class'      => 'success',
			'content'    => 'Green box selected!',
			'dependency' => array( 'dep_7_green', '==', 'true' ),
		),

		array(
			'id'         => 'dep_7_alt',
			'type'       => 'image_select',
			'title'      => 'If check <u>Green box or Blue box</u> (radio)',
			'options'    => array(
				'green'  => 'https://codestarframework.com/assets/images/placeholder/100x80-2ecc71.gif',
				'red'    => 'https://codestarframework.com/assets/images/placeholder/100x80-e74c3c.gif',
				'yellow' => 'https://codestarframework.com/assets/images/placeholder/100x80-ffbc00.gif',
				'blue'   => 'https://codestarframework.com/assets/images/placeholder/100x80-3498db.gif',
				'gray'   => 'https://codestarframework.com/assets/images/placeholder/100x80-555555.gif',
			),
			'info'       => 'Multipel Image select field input="radio" model. in radio model unselected unavailable.',
			'radio'      => true,
			'default'    => 'gray',
			'attributes' => array(
				'data-depend-id' => 'dep_7_alt',
			),
		),

		array(
			'type'       => 'notice',
			'class'      => 'success',
			'content'    => 'Green or Blue box selected!',
			'dependency' => array( 'dep_7_alt', 'any', 'green,blue' ),
		),

		array(
			'id'    => 'dep_8',
			'type'  => 'image',
			'title' => 'Add a image',
		),

		array(
			'type'       => 'notice',
			'class'      => 'success',
			'content'    => 'Added a image!',
			'dependency' => array( 'dep_8', '!=', '' ),
		),

		array(
			'id'    => 'dep_9',
			'type'  => 'icon',
			'title' => 'Add a icon',
		),

		array(
			'type'       => 'notice',
			'class'      => 'success',
			'content'    => 'Added a icon!',
			'dependency' => array( 'dep_9', '!=', '' ),
		),

		array(
			'type'    => 'subheading',
			'content' => 'Advanced Dependencies',
		),

		array(
			'id'    => 'dep_10',
			'type'  => 'text',
			'title' => 'If text string <u>hello</u>',
		),

		array(
			'id'    => 'dep_11',
			'type'  => 'text',
			'title' => 'and this text string <u>world</u>',
		),

		array(
			'id'    => 'dep_12',
			'type'  => 'checkbox',
			'title' => 'and checkbox mode <u>checked</u>',
			'label' => 'Check me!',
		),

		array(
			'type'       => 'notice',
			'class'      => 'info',
			'content'    => 'Done, Multiple Dependencies worked.',
			'dependency' => array( 'dep_10|dep_11|dep_12', '==|==|==', 'hello|world|true' ),
		),

		array(
			'type'    => 'subheading',
			'content' => 'Another Dependencies',
		),

		array(
			'id'      => 'dep_13',
			'type'    => 'select',
			'title'   => 'If color <u>black or white</u>',
			'options' => array(
				'blue'  => 'Blue',
				'black' => 'Black',
				'white' => 'White',
			),
		),

		array(
			'id'      => 'dep_14',
			'type'    => 'select',
			'title'   => 'If size <u>middle</u>',
			'options' => array(
				'small'  => 'Small',
				'middle' => 'Middle',
				'large'  => 'Large',
				'xlage'  => 'XLarge',
			),
		),

		array(
			'id'         => 'dep_15',
			'type'       => 'select',
			'title'      => 'If text is <u>world</u>',
			'options'    => array(
				'hello' => 'Hello',
				'world' => 'World',
			),
			'dependency' => array( 'dep_13|dep_14', 'any|==', 'black,white|middle' ),
		),

		array(
			'type'       => 'notice',
			'class'      => 'info',
			'content'    => 'Well done, Correctly!',
			'dependency' => array( 'dep_15', '==', 'world' ),
		),

	),
);

//
// Seperator
//
$options[] = array(
	'name'  => 'seperator_2',
	'title' => 'Section Examples',
	'icon'  => 'fa fa-cog',
);

//
// Section
//
$options[] = array(
	'name'   => 'normal_section',
	'title'  => 'Normal Section',
	'icon'   => 'fa fa-minus',
	'fields' => array(

		array(
			'type'    => 'content',
			'content' => 'This section is empty, add some options...',
		),

	),
);

//
// Dependencies
//
$options[] = array(
	'name'     => 'accordion_section',
	'title'    => 'Accordion Sections',
	'icon'     => 'fa fa-bars',
	'sections' => array(

		array(
			'name'   => 'sub_section_1',
			'title'  => 'Sub Sections 1',
			'icon'   => 'fa fa-minus',
			'fields' => array(

				array(
					'type'    => 'content',
					'content' => 'This section 1 is empty, add some options...',
				),

			),
		),

		array(
			'name'   => 'sub_section_2',
			'title'  => 'Sub Sections 2',
			'icon'   => 'fa fa-minus',
			'fields' => array(

				array(
					'type'    => 'content',
					'content' => 'This section 2 is empty, add some options...',
				),

			),
		),

		array(
			'name'   => 'sub_section_3',
			'title'  => 'Sub Sections 3',
			'icon'   => 'fa fa-minus',
			'fields' => array(

				array(
					'type'    => 'content',
					'content' => 'This section 3 is empty, add some options...',
				),

			),
		),

	),
);

OVIC_Options::instance( $settings, $options );