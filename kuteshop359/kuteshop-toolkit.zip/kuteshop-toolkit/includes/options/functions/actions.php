<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Get icons from admin ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !function_exists( 'ovic_get_icons' ) ) {
	function ovic_get_icons()
	{
		if ( !empty( $_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'ovic_icon_nonce' ) ) {
			ob_start();

			OVIC::include_plugin_file( 'fields/icon/default-icons.php' );

			$default_icon = function_exists( 'ovic_get_default_icons' ) ? ovic_get_default_icons() : array();

			$icon_lists = apply_filters( 'ovic_field_icon_add_icons', $default_icon );

			if ( !empty( $icon_lists ) ) {
				foreach ( $icon_lists as $list ) {
					echo ( count( $icon_lists ) >= 2 ) ? '<div class="ovic-icon-title">' . $list['title'] . '</div>' : '';

					foreach ( $list['icons'] as $icon ) {
						echo '<a class="ovic-icon-tooltip" data-ovic-icon="' . $icon . '" title="' . $icon . '"><span class="ovic-icon ovic-selector"><i class="' . $icon . '"></i></span></a>';
					}
				}
			} else {
				echo '<div class="ovic-text-error">' . esc_html__( 'No data provided by developer', 'ovic-addon-toolkit' ) . '</div>';
			}

			wp_send_json_success( array( 'success' => true, 'content' => ob_get_clean() ) );
		} else {
			wp_send_json_error( array( 'success' => false, 'error' => esc_html__( 'Error while saving.', 'ovic-addon-toolkit' ), 'debug' => $_REQUEST ) );
		}
	}

	add_action( 'wp_ajax_ovic-get-icons', 'ovic_get_icons' );
}
/**
 *
 * Export
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !function_exists( 'ovic_export' ) ) {
	function ovic_export()
	{
		if ( !empty( $_GET['export'] ) && !empty( $_GET['nonce'] ) && wp_verify_nonce( $_GET['nonce'], 'ovic_backup_nonce' ) ) {
			header( 'Content-Type: plain/text' );
			header( 'Content-disposition: attachment; filename=backup-' . gmdate( 'd-m-Y' ) . '.txt' );
			header( 'Content-Transfer-Encoding: binary' );
			header( 'Pragma: no-cache' );
			header( 'Expires: 0' );

			echo json_encode( get_option( wp_unslash( $_GET['export'] ) ) );
		}

		wp_die();
	}

	add_action( 'wp_ajax_ovic-export', 'ovic_export' );
}
/**
 *
 * Import Ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !function_exists( 'ovic_import_ajax' ) ) {
	function ovic_import_ajax()
	{
		if ( !empty( $_POST['import_data'] ) && !empty( $_POST['unique'] ) && !empty( $_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'ovic_backup_nonce' ) ) {
			$import_data = json_decode( wp_unslash( trim( $_POST['import_data'] ) ), true );

			if ( is_array( $import_data ) ) {
				update_option( wp_unslash( $_POST['unique'] ), wp_unslash( $import_data ) );
				wp_send_json_success( array( 'success' => true ) );
			}
		}

		wp_send_json_error( array( 'success' => false, 'error' => esc_html__( 'Error while saving.', 'ovic-addon-toolkit' ), 'debug' => $_REQUEST ) );
	}

	add_action( 'wp_ajax_ovic-import', 'ovic_import_ajax' );
}

/**
 *
 * Reset Ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !function_exists( 'ovic_reset_ajax' ) ) {
	function ovic_reset_ajax()
	{
		if ( !empty( $_POST['unique'] ) && !empty( $_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'ovic_backup_nonce' ) ) {
			delete_option( wp_unslash( $_POST['unique'] ) );
			wp_send_json_success( array( 'success' => true ) );
		}

		wp_send_json_error( array( 'success' => false, 'error' => esc_html__( 'Error while saving.', 'ovic-addon-toolkit' ), 'debug' => $_REQUEST ) );
	}

	add_action( 'wp_ajax_ovic-reset', 'ovic_reset_ajax' );
}
/**
 *
 * Set icons for wp dialog
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !function_exists( 'ovic_set_icons' ) ) {
	function ovic_set_icons()
	{
		if ( wp_script_is( 'ovic-options' ) && wp_style_is( 'ovic-options' ) ) :
			?>
            <div id="ovic-modal-icon" class="ovic-modal ovic-modal-icon">
                <div class="ovic-modal-table">
                    <div class="ovic-modal-table-cell">
                        <div class="ovic-modal-overlay"></div>
                        <div class="ovic-modal-inner">
                            <div class="ovic-modal-title">
								<?php esc_html_e( 'Add Icon', 'ovic-addon-toolkit' ); ?>
                                <div class="ovic-modal-close ovic-icon-close"></div>
                            </div>
                            <div class="ovic-modal-header ovic-text-center">
                                <input type="text"
                                       placeholder="<?php esc_attr_e( 'Search a Icon...', 'ovic-addon-toolkit' ); ?>"
                                       class="ovic-icon-search"/>
                            </div>
                            <div class="ovic-modal-content">
                                <div class="ovic-modal-loading">
                                    <div class="ovic-loading"></div>
                                </div>
                                <div class="ovic-modal-load"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		<?php
		endif;
	}

	add_action( 'admin_footer', 'ovic_set_icons' );
	add_action( 'customize_controls_print_footer_scripts', 'ovic_set_icons' );
}
