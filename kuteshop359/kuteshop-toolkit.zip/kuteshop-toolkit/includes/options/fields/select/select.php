<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Field: select
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !class_exists( 'OVIC_Field_select' ) ) {
	class OVIC_Field_select extends OVIC_Fields
	{
		public function __construct( $field, $value = '', $unique = '', $where = '', $parent = '' )
		{
			parent::__construct( $field, $value, $unique, $where, $parent );
		}

		public function render()
		{
			$args = wp_parse_args( $this->field, array(
					'chosen'      => false,
					'multiple'    => false,
					'placeholder' => '',
				)
			);

			$this->lang_value = ( is_array( $this->lang_value ) ) ? $this->lang_value : array_filter( (array)$this->lang_value );

			echo $this->field_before();

			if ( !empty( $this->field['options'] ) ) {
				$options          = ( is_array( $this->field['options'] ) ) ? $this->field['options'] : $this->field_data( $this->field['options'] );
				$multiple_name    = ( $args['multiple'] ) ? '[]' : '';
				$multiple_attr    = ( $args['multiple'] ) ? ' multiple="multiple"' : '';
				$chosen_attr      = ( $args['chosen'] ) ? ' class="ovic-chosen"' : '';
				$placeholder_attr = ( $args['chosen'] && $args['placeholder'] ) ? ' data-placeholder="' . $args['placeholder'] . '"' : '';

				if ( !empty( $options ) ) {
					echo '<select name="' . $this->field_name( $multiple_name ) . '"' . $multiple_attr . $chosen_attr . $placeholder_attr . $this->field_attributes() . '>';

					if ( $args['placeholder'] && empty( $args['multiple'] ) ) {
						if ( !empty( $args['chosen'] ) ) {
							echo '<option value=""></option>';
						} else {
							echo '<option value="">' . $args['placeholder'] . '</option>';
						}
					}

					foreach ( $options as $option_key => $option ) {
						if ( is_array( $option ) && !empty( $option ) ) {
							echo '<optgroup label="' . $option_key . '">';

							foreach ( $option as $sub_key => $sub_value ) {
								$selected = ( in_array( $sub_key, $this->lang_value ) ) ? ' selected' : '';
								echo '<option value="' . $sub_key . '" ' . $selected . '>' . $sub_value . '</option>';
							}

							echo '</optgroup>';
						} else {
							$selected = ( in_array( $option_key, $this->lang_value ) ) ? ' selected' : '';
							echo '<option value="' . $option_key . '" ' . $selected . '>' . $option . '</option>';
						}
					}

					echo '</select>';
				} else {
					echo esc_html__( 'No data provided for this option type.', 'ovic-addon-toolkit' );
				}
			}

			echo $this->field_after();
		}
	}
}
