<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Field: Number
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !class_exists( 'OVIC_Field_number' ) ) {
	class OVIC_Field_number extends OVIC_Fields
	{
		public function __construct( $field, $value = '', $unique = '', $where = '' )
		{
			parent::__construct( $field, $value, $unique, $where );
		}

		public function render()
		{
			echo $this->field_before();
			$unit = ( isset( $this->field['unit'] ) ) ? '<em>' . $this->field['unit'] . '</em>' : '';
			echo '<input type="number" name="' . $this->field_name() . '" value="' . $this->field_value() . '"' . $this->field_class() . $this->field_attributes() . '/>' . $unit;
			echo $this->field_after();
		}
	}
}
