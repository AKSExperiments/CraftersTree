<?php if ( !defined( 'ABSPATH' ) ) {
	die;
} // Cannot access pages directly.
/**
 *
 * Field: upload
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( !class_exists( 'OVIC_Field_upload' ) ) {
	class OVIC_Field_upload extends OVIC_Fields
	{
		public function __construct( $field, $value = '', $unique = '', $where = '', $parent = '' )
		{
			parent::__construct( $field, $value, $unique, $where, $parent );
		}

		public function render()
		{
			$settings = ( !empty( $this->field['settings'] ) ) ? $this->field['settings'] : array();
			$args     = wp_parse_args( $settings, array(
					'library'      => array(),
					'button_title' => esc_html__( 'Upload', 'ovic-addon-toolkit' ),
					'frame_title'  => esc_html__( 'Upload', 'ovic-addon-toolkit' ),
					'remove_title' => esc_html__( 'Remove', 'ovic-addon-toolkit' ),
					'insert_title' => esc_html__( 'Use Image', 'ovic-addon-toolkit' ),
				)
			);

			echo $this->field_before();

			$library = ( is_array( $args['library'] ) ) ? $args['library'] : array_filter( (array)$args['library'] );
			$library = ( !empty( $library ) ) ? implode( ',', $library ) : '';
			$hidden  = ( empty( $this->lang_value ) ) ? ' hidden' : '';

			if ( !empty( $this->field['preview'] ) ) {
				$preview_src = '';
				$hidden_auto = ' hidden';
				$exts        = array( 'jpg', 'gif', 'png', 'svg', 'jpeg' );
				$exp         = explode( '.', $this->lang_value );
				$ext         = ( !empty( $exp ) ) ? end( $exp ) : '';
				if ( !empty( $this->lang_value ) && in_array( $ext, $exts ) ) {
					$hidden_auto = '';
					$preview_src = $this->lang_value;
				}

				echo '<div class="ovic--preview' . $hidden_auto . '">';
				echo '<div class="ovic-image-preview"><a href="#" class="ovic--remove fa fa-times"></a><img src="' . $preview_src . '" alt="preview" class="ovic--src" /></div>';
				echo '</div>';
			}

			echo '<div class="ovic--wrap">';
			echo '<input type="text" name="' . $this->field_name() . '" value="' . $this->lang_value . '"' . $this->field_attributes() . '/>';
			echo '<div class="ovic--buttons">';
			echo '<a href="#" class="button button-primary ovic--button" data-library="' . esc_attr( $library ) . '" data-frame-title="' . esc_attr( $args['frame_title'] ) . '" data-insert-title="' . esc_attr( $args['frame_title'] ) . '">' . $args['button_title'] . '</a>';
			echo '<a href="#" class="button button-secondary ovic-warning-primary ovic--remove' . $hidden . '">' . $args['remove_title'] . '</a>';
			echo '</div>';
			echo '</div>';

			echo $this->field_after();
		}
	}
}
