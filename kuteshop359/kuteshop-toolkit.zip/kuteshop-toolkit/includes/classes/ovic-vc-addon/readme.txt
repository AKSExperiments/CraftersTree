=== Ovic Responsive WPBakery ===

Contributors: https://kutethemes.com/
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=A3GMPNUKXFVJ2&source=url
Tags: responsive, responsive shortcode, responsive visual, responsive multi screen
Requires at least: 3.0.1
Tested up to: 5.2
Requires PHP: 5.6
Stable tag: 5.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The Responsive WPBakery For extent Visual Composer.
- Responsive all shortcode WPBakery
- Responsive multi screen

= Need support? =

Contact [contact](https://kutethemes.com/ "contact")

== Installation ==

1. Please make sure that you installed WPBakery plugin
2. Go to plugins in your dashboard and select "Add New"
3. Search for "Ovic Responsive WPBakery", Install & Activate it
4. Now you can find menu Ovic Plugins => Ovic WPBakery for settings.

== Changelog ==

= 1.0.7 =

* Released