=== Kuteshop Toolkit ===

Contributors: Ovic Team
Tags: ecommerce, e-commerce, store, sales, sell, shop, cart, checkout, downloadable, downloads, paypal, storefront, woo commerce
Requires at least: 4.7
Tested up to: 4.9
Stable tag: 3.4.4
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==

https://kutethemes.com

== Installation ==

* PHP version 5.2.4 or greater (PHP 7.2 or greater is recommended)
* MySQL version 5.0 or greater (MySQL 5.6 or greater is recommended)

== Changelog ==

= Version: 1.1.8 - 25/10/2018 =

UPDATE:

- Update options Enable/Disable responsive visual builder.

Initial release