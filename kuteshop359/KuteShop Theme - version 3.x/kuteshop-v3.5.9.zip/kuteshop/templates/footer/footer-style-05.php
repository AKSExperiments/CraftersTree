<?php
/**
 * Name:  Footer style 05
 **/
?>
<footer class="footer style5">
    <div class="container">
		<?php the_content(); ?>
    </div>
</footer>