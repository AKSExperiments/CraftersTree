<?php
/**
 * Name:  Footer style 03
 **/
?>
<footer class="footer style3">
    <div class="container">
		<?php the_content(); ?>
    </div>
</footer>