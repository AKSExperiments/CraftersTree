<?php
/**
 * Name:  Footer style 08
 **/
?>
<footer class="footer style8">
    <div class="container">
		<?php the_content(); ?>
    </div>
</footer>