<?php
/**
 * Name:  Footer style 07
 **/
?>
<footer class="footer style7">
	<div class="container">
		<?php the_content(); ?>
	</div>
</footer>